--
-- PostgreSQL database dump
--

\restrict QYRHj8JNfTlcnSSfowGjls5NMUjuI5ZnhBi5bjMEmgUG54MKEWhASEEsdniDMYk

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_user_id_c564eba6_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.core_wholesaledevicesale DROP CONSTRAINT IF EXISTS core_wholesaledevicesale_sold_by_id_eb34326c_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_wholesaledevicesale DROP CONSTRAINT IF EXISTS core_wholesaledevicesale_branch_id_df2085be_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_wholesaledevice DROP CONSTRAINT IF EXISTS core_wholesaledevice_staff_id_c0597b80_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_wholesaledevicesale DROP CONSTRAINT IF EXISTS core_wholesaledevice_device_id_fdf59509_fk_core_whol;
ALTER TABLE IF EXISTS ONLY public.core_wholesaledevice DROP CONSTRAINT IF EXISTS core_wholesaledevice_branch_id_41cd184f_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_user_user_permissions DROP CONSTRAINT IF EXISTS core_user_user_permissions_user_id_085123d3_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_user_user_permissions DROP CONSTRAINT IF EXISTS core_user_user_permi_permission_id_35ccf601_fk_auth_perm;
ALTER TABLE IF EXISTS ONLY public.core_user_groups DROP CONSTRAINT IF EXISTS core_user_groups_user_id_70b4d9b8_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_user_groups DROP CONSTRAINT IF EXISTS core_user_groups_group_id_fe8c697f_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.core_user DROP CONSTRAINT IF EXISTS core_user_branch_id_90a0c1d9_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_stockrequest DROP CONSTRAINT IF EXISTS core_stockrequest_staff_id_f5d71b91_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_stockrequest DROP CONSTRAINT IF EXISTS core_stockrequest_branch_id_ae6f9056_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_stockmovement DROP CONSTRAINT IF EXISTS core_stockmovement_product_id_bd647177_fk_core_product_id;
ALTER TABLE IF EXISTS ONLY public.core_stockmovement DROP CONSTRAINT IF EXISTS core_stockmovement_performed_by_id_1b6db32d_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_stockmovement DROP CONSTRAINT IF EXISTS core_stockmovement_branch_id_c888bf1e_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_stockalert DROP CONSTRAINT IF EXISTS core_stockalert_product_id_e0d51944_fk_core_product_id;
ALTER TABLE IF EXISTS ONLY public.core_stockalert DROP CONSTRAINT IF EXISTS core_stockalert_branch_id_5d6c66dd_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_staffstock DROP CONSTRAINT IF EXISTS core_staffstock_staff_id_ae8d0304_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_staffstock DROP CONSTRAINT IF EXISTS core_staffstock_product_id_80875aa3_fk_core_product_id;
ALTER TABLE IF EXISTS ONLY public.core_siminventorylog DROP CONSTRAINT IF EXISTS core_siminventorylog_inventory_id_08c2f765_fk_core_simi;
ALTER TABLE IF EXISTS ONLY public.core_siminventorylog DROP CONSTRAINT IF EXISTS core_siminventorylog_created_by_id_0370e6ad_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_siminventory DROP CONSTRAINT IF EXISTS core_siminventory_branch_id_981a3e5e_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_servicetarget DROP CONSTRAINT IF EXISTS core_servicetarget_device_tag_id_25543dda_fk_core_devicetag_id;
ALTER TABLE IF EXISTS ONLY public.core_servicetarget DROP CONSTRAINT IF EXISTS core_servicetarget_created_by_id_dc58be38_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_servicetarget DROP CONSTRAINT IF EXISTS core_servicetarget_branch_id_556d2522_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_serviceactivity DROP CONSTRAINT IF EXISTS core_serviceactivity_staff_id_c3b6d88a_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_serviceactivity DROP CONSTRAINT IF EXISTS core_serviceactivity_device_tag_id_9cd095e8_fk_core_devi;
ALTER TABLE IF EXISTS ONLY public.core_serviceactivity DROP CONSTRAINT IF EXISTS core_serviceactivity_branch_id_f18d27ff_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_retailsubsubcategory DROP CONSTRAINT IF EXISTS core_retailsubsubcat_subcategory_id_b5a83487_fk_core_reta;
ALTER TABLE IF EXISTS ONLY public.core_retailsubcategory DROP CONSTRAINT IF EXISTS core_retailsubcatego_category_id_0b204b65_fk_core_reta;
ALTER TABLE IF EXISTS ONLY public.core_retailsale DROP CONSTRAINT IF EXISTS core_retailsale_voided_by_id_a2926419_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_retailsale DROP CONSTRAINT IF EXISTS core_retailsale_staff_id_0585cf0f_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_retailsale DROP CONSTRAINT IF EXISTS core_retailsale_product_id_e7e0c289_fk_core_product_id;
ALTER TABLE IF EXISTS ONLY public.core_retailsale DROP CONSTRAINT IF EXISTS core_retailsale_branch_id_75cf7c8a_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_purchaseorderitem DROP CONSTRAINT IF EXISTS core_purchaseorderitem_product_id_e4cc27f0_fk_core_product_id;
ALTER TABLE IF EXISTS ONLY public.core_purchaseorderitem DROP CONSTRAINT IF EXISTS core_purchaseorderit_order_id_b76edeae_fk_core_purc;
ALTER TABLE IF EXISTS ONLY public.core_purchaseorder DROP CONSTRAINT IF EXISTS core_purchaseorder_supplier_id_0242d2c5_fk_core_supplier_id;
ALTER TABLE IF EXISTS ONLY public.core_purchaseorder DROP CONSTRAINT IF EXISTS core_purchaseorder_ordered_by_id_94964a24_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_purchaseorder DROP CONSTRAINT IF EXISTS core_purchaseorder_branch_id_b1f3f892_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_product DROP CONSTRAINT IF EXISTS core_product_subsubcategory_id_a59205c3_fk_core_reta;
ALTER TABLE IF EXISTS ONLY public.core_product DROP CONSTRAINT IF EXISTS core_product_subcategory_id_eff25cab_fk_core_reta;
ALTER TABLE IF EXISTS ONLY public.core_performance DROP CONSTRAINT IF EXISTS core_performance_staff_id_4328b87d_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_performance DROP CONSTRAINT IF EXISTS core_performance_branch_id_b7a354e1_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_notification DROP CONSTRAINT IF EXISTS core_notification_recipient_id_24a3d95c_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_multichoiceweeklyreport DROP CONSTRAINT IF EXISTS core_multichoiceweeklyreport_staff_id_0fcbbc31_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_multichoiceweeklyreport DROP CONSTRAINT IF EXISTS core_multichoiceweek_branch_id_d1e4fbc9_fk_core_bran;
ALTER TABLE IF EXISTS ONLY public.core_multichoicesale DROP CONSTRAINT IF EXISTS core_multichoicesale_staff_id_3e71ba63_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_multichoicesale DROP CONSTRAINT IF EXISTS core_multichoicesale_branch_id_f83238d1_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_multichoicebalance DROP CONSTRAINT IF EXISTS core_multichoicebala_weekly_report_id_d305aa7c_fk_core_mult;
ALTER TABLE IF EXISTS ONLY public.core_moniepointtransaction DROP CONSTRAINT IF EXISTS core_moniepointtransaction_staff_id_cd344dc2_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_moniepointtransaction DROP CONSTRAINT IF EXISTS core_moniepointtransaction_branch_id_26f2a786_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_loyaltytransaction DROP CONSTRAINT IF EXISTS core_loyaltytransaction_created_by_id_dea26ffe_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_loyaltytransaction DROP CONSTRAINT IF EXISTS core_loyaltytransact_loyalty_point_id_7b980755_fk_core_loya;
ALTER TABLE IF EXISTS ONLY public.core_loyaltypoint DROP CONSTRAINT IF EXISTS core_loyaltypoint_customer_id_0041d3d7_fk_core_customer_id;
ALTER TABLE IF EXISTS ONLY public.core_loyaltypoint DROP CONSTRAINT IF EXISTS core_loyaltypoint_branch_id_09e6d80f_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_invoice DROP CONSTRAINT IF EXISTS core_invoice_staff_id_7fc96d3e_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_invoice DROP CONSTRAINT IF EXISTS core_invoice_branch_id_f40e78fa_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_expense DROP CONSTRAINT IF EXISTS core_expense_branch_id_8acf5255_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_directorsafestock DROP CONSTRAINT IF EXISTS core_directorsafestock_product_id_38047829_fk_core_product_id;
ALTER TABLE IF EXISTS ONLY public.core_devicetagcommission DROP CONSTRAINT IF EXISTS core_devicetagcommission_created_by_id_4e2b6094_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_devicetagcommission DROP CONSTRAINT IF EXISTS core_devicetagcommission_branch_id_06622e36_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_devicetagcommission DROP CONSTRAINT IF EXISTS core_devicetagcommis_device_tag_id_6d3f1635_fk_core_devi;
ALTER TABLE IF EXISTS ONLY public.core_devicetag DROP CONSTRAINT IF EXISTS core_devicetag_branch_id_019fb7fd_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_customer DROP CONSTRAINT IF EXISTS core_customer_branch_id_8e5d442d_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_commissionpayment DROP CONSTRAINT IF EXISTS core_commissionpayment_staff_id_99258308_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_commissionpayment DROP CONSTRAINT IF EXISTS core_commissionpayment_branch_id_b6bc2b60_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_commissionpayment DROP CONSTRAINT IF EXISTS core_commissionpayme_balance_record_id_663a2ce3_fk_core_mult;
ALTER TABLE IF EXISTS ONLY public.core_checkinoutlog DROP CONSTRAINT IF EXISTS core_checkinoutlog_staff_id_74d62d1e_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_checkinoutlog DROP CONSTRAINT IF EXISTS core_checkinoutlog_branch_id_eb1f0b14_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_branchsafestock DROP CONSTRAINT IF EXISTS core_branchsafestock_product_id_d019c34d_fk_core_product_id;
ALTER TABLE IF EXISTS ONLY public.core_branchsafestock DROP CONSTRAINT IF EXISTS core_branchsafestock_branch_id_bdc9012d_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.core_auditlog DROP CONSTRAINT IF EXISTS core_auditlog_user_id_3797aaab_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_attendance DROP CONSTRAINT IF EXISTS core_attendance_user_id_fdad1ea2_fk_core_user_id;
ALTER TABLE IF EXISTS ONLY public.core_attendance DROP CONSTRAINT IF EXISTS core_attendance_branch_id_1b7e28be_fk_core_branch_id;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
DROP INDEX IF EXISTS public.django_session_session_key_c0390e0f_like;
DROP INDEX IF EXISTS public.django_session_expire_date_a5c62663;
DROP INDEX IF EXISTS public.django_admin_log_user_id_c564eba6;
DROP INDEX IF EXISTS public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX IF EXISTS public.core_wholesaledevicesale_sold_by_id_eb34326c;
DROP INDEX IF EXISTS public.core_wholesaledevicesale_device_id_fdf59509;
DROP INDEX IF EXISTS public.core_wholesaledevicesale_branch_id_df2085be;
DROP INDEX IF EXISTS public.core_wholesaledevice_staff_id_c0597b80;
DROP INDEX IF EXISTS public.core_wholesaledevice_branch_id_41cd184f;
DROP INDEX IF EXISTS public.core_wholes_branch__b961f7_idx;
DROP INDEX IF EXISTS public.core_user_username_36e4f7f7_like;
DROP INDEX IF EXISTS public.core_user_user_permissions_user_id_085123d3;
DROP INDEX IF EXISTS public.core_user_user_permissions_permission_id_35ccf601;
DROP INDEX IF EXISTS public.core_user_groups_user_id_70b4d9b8;
DROP INDEX IF EXISTS public.core_user_groups_group_id_fe8c697f;
DROP INDEX IF EXISTS public.core_user_branch_id_90a0c1d9;
DROP INDEX IF EXISTS public.core_stockrequest_staff_id_f5d71b91;
DROP INDEX IF EXISTS public.core_stockrequest_branch_id_ae6f9056;
DROP INDEX IF EXISTS public.core_stockmovement_product_id_bd647177;
DROP INDEX IF EXISTS public.core_stockmovement_performed_by_id_1b6db32d;
DROP INDEX IF EXISTS public.core_stockmovement_branch_id_c888bf1e;
DROP INDEX IF EXISTS public.core_stockalert_product_id_e0d51944;
DROP INDEX IF EXISTS public.core_stockalert_branch_id_5d6c66dd;
DROP INDEX IF EXISTS public.core_staffstock_staff_id_ae8d0304;
DROP INDEX IF EXISTS public.core_staffstock_product_id_80875aa3;
DROP INDEX IF EXISTS public.core_siminventorylog_inventory_id_08c2f765;
DROP INDEX IF EXISTS public.core_siminventorylog_created_by_id_0370e6ad;
DROP INDEX IF EXISTS public.core_servicetarget_device_tag_id_25543dda;
DROP INDEX IF EXISTS public.core_servicetarget_created_by_id_dc58be38;
DROP INDEX IF EXISTS public.core_servicetarget_branch_id_556d2522;
DROP INDEX IF EXISTS public.core_serviceactivity_staff_id_c3b6d88a;
DROP INDEX IF EXISTS public.core_serviceactivity_device_tag_id_9cd095e8;
DROP INDEX IF EXISTS public.core_serviceactivity_branch_id_f18d27ff;
DROP INDEX IF EXISTS public.core_retailsubsubcategory_subcategory_id_b5a83487;
DROP INDEX IF EXISTS public.core_retailsubcategory_category_id_0b204b65;
DROP INDEX IF EXISTS public.core_retailsale_voided_by_id_a2926419;
DROP INDEX IF EXISTS public.core_retailsale_staff_id_0585cf0f;
DROP INDEX IF EXISTS public.core_retailsale_product_id_e7e0c289;
DROP INDEX IF EXISTS public.core_retailsale_branch_id_75cf7c8a;
DROP INDEX IF EXISTS public.core_retail_staff_i_14e004_idx;
DROP INDEX IF EXISTS public.core_retail_date_1b32aa_idx;
DROP INDEX IF EXISTS public.core_retail_branch__f5443e_idx;
DROP INDEX IF EXISTS public.core_purchaseorderitem_product_id_e4cc27f0;
DROP INDEX IF EXISTS public.core_purchaseorderitem_order_id_b76edeae;
DROP INDEX IF EXISTS public.core_purchaseorder_supplier_id_0242d2c5;
DROP INDEX IF EXISTS public.core_purchaseorder_ordered_by_id_94964a24;
DROP INDEX IF EXISTS public.core_purchaseorder_branch_id_b1f3f892;
DROP INDEX IF EXISTS public.core_product_subsubcategory_id_a59205c3;
DROP INDEX IF EXISTS public.core_product_subcategory_id_eff25cab;
DROP INDEX IF EXISTS public.core_product_imei_serial_0fb3889a_like;
DROP INDEX IF EXISTS public.core_performance_staff_id_4328b87d;
DROP INDEX IF EXISTS public.core_performance_branch_id_b7a354e1;
DROP INDEX IF EXISTS public.core_notification_recipient_id_24a3d95c;
DROP INDEX IF EXISTS public.core_multichoiceweeklyreport_staff_id_0fcbbc31;
DROP INDEX IF EXISTS public.core_multichoiceweeklyreport_branch_id_d1e4fbc9;
DROP INDEX IF EXISTS public.core_multichoicesale_staff_id_3e71ba63;
DROP INDEX IF EXISTS public.core_multichoicesale_branch_id_f83238d1;
DROP INDEX IF EXISTS public.core_multichoicebalance_weekly_report_id_d305aa7c;
DROP INDEX IF EXISTS public.core_moniepointtransaction_transaction_id_8c7295ce_like;
DROP INDEX IF EXISTS public.core_moniepointtransaction_staff_id_cd344dc2;
DROP INDEX IF EXISTS public.core_moniepointtransaction_branch_id_26f2a786;
DROP INDEX IF EXISTS public.core_moniep_transac_9a6271_idx;
DROP INDEX IF EXISTS public.core_moniep_status_064e2b_idx;
DROP INDEX IF EXISTS public.core_moniep_branch__8564a7_idx;
DROP INDEX IF EXISTS public.core_loyaltytransaction_loyalty_point_id_7b980755;
DROP INDEX IF EXISTS public.core_loyaltytransaction_created_by_id_dea26ffe;
DROP INDEX IF EXISTS public.core_loyaltypoint_customer_id_0041d3d7;
DROP INDEX IF EXISTS public.core_loyaltypoint_branch_id_09e6d80f;
DROP INDEX IF EXISTS public.core_invoice_staff_id_7fc96d3e;
DROP INDEX IF EXISTS public.core_invoice_invoice_number_052322d2_like;
DROP INDEX IF EXISTS public.core_invoice_branch_id_f40e78fa;
DROP INDEX IF EXISTS public.core_expense_branch_id_8acf5255;
DROP INDEX IF EXISTS public.core_directorsafestock_product_id_38047829;
DROP INDEX IF EXISTS public.core_devicetagcommission_device_tag_id_6d3f1635;
DROP INDEX IF EXISTS public.core_devicetagcommission_created_by_id_4e2b6094;
DROP INDEX IF EXISTS public.core_devicetagcommission_branch_id_06622e36;
DROP INDEX IF EXISTS public.core_devicetag_branch_id_019fb7fd;
DROP INDEX IF EXISTS public.core_customer_phone_number_623ed62a_like;
DROP INDEX IF EXISTS public.core_customer_branch_id_8e5d442d;
DROP INDEX IF EXISTS public.core_commissionpayment_staff_id_99258308;
DROP INDEX IF EXISTS public.core_commissionpayment_branch_id_b6bc2b60;
DROP INDEX IF EXISTS public.core_commissionpayment_balance_record_id_663a2ce3;
DROP INDEX IF EXISTS public.core_checkinoutlog_staff_id_74d62d1e;
DROP INDEX IF EXISTS public.core_checkinoutlog_branch_id_eb1f0b14;
DROP INDEX IF EXISTS public.core_branchsafestock_product_id_d019c34d;
DROP INDEX IF EXISTS public.core_branchsafestock_branch_id_bdc9012d;
DROP INDEX IF EXISTS public.core_auditlog_user_id_3797aaab;
DROP INDEX IF EXISTS public.core_auditl_model_n_078933_idx;
DROP INDEX IF EXISTS public.core_attendance_user_id_fdad1ea2;
DROP INDEX IF EXISTS public.core_attendance_branch_id_1b7e28be;
DROP INDEX IF EXISTS public.auth_permission_content_type_id_2f476e4b;
DROP INDEX IF EXISTS public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX IF EXISTS public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX IF EXISTS public.auth_group_name_a6ea08ec_like;
ALTER TABLE IF EXISTS ONLY public.django_session DROP CONSTRAINT IF EXISTS django_session_pkey;
ALTER TABLE IF EXISTS ONLY public.django_migrations DROP CONSTRAINT IF EXISTS django_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_pkey;
ALTER TABLE IF EXISTS ONLY public.core_wholesaledevicesale DROP CONSTRAINT IF EXISTS core_wholesaledevicesale_pkey;
ALTER TABLE IF EXISTS ONLY public.core_wholesaledevice DROP CONSTRAINT IF EXISTS core_wholesaledevice_pkey;
ALTER TABLE IF EXISTS ONLY public.core_user DROP CONSTRAINT IF EXISTS core_user_username_key;
ALTER TABLE IF EXISTS ONLY public.core_user_user_permissions DROP CONSTRAINT IF EXISTS core_user_user_permissions_user_id_permission_id_73ea0daa_uniq;
ALTER TABLE IF EXISTS ONLY public.core_user_user_permissions DROP CONSTRAINT IF EXISTS core_user_user_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.core_user DROP CONSTRAINT IF EXISTS core_user_pkey;
ALTER TABLE IF EXISTS ONLY public.core_user_groups DROP CONSTRAINT IF EXISTS core_user_groups_user_id_group_id_c82fcad1_uniq;
ALTER TABLE IF EXISTS ONLY public.core_user_groups DROP CONSTRAINT IF EXISTS core_user_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.core_supplier DROP CONSTRAINT IF EXISTS core_supplier_pkey;
ALTER TABLE IF EXISTS ONLY public.core_stockrequest DROP CONSTRAINT IF EXISTS core_stockrequest_pkey;
ALTER TABLE IF EXISTS ONLY public.core_stockmovement DROP CONSTRAINT IF EXISTS core_stockmovement_pkey;
ALTER TABLE IF EXISTS ONLY public.core_stockalert DROP CONSTRAINT IF EXISTS core_stockalert_pkey;
ALTER TABLE IF EXISTS ONLY public.core_staffstock DROP CONSTRAINT IF EXISTS core_staffstock_pkey;
ALTER TABLE IF EXISTS ONLY public.core_siminventorylog DROP CONSTRAINT IF EXISTS core_siminventorylog_pkey;
ALTER TABLE IF EXISTS ONLY public.core_siminventory DROP CONSTRAINT IF EXISTS core_siminventory_pkey;
ALTER TABLE IF EXISTS ONLY public.core_siminventory DROP CONSTRAINT IF EXISTS core_siminventory_branch_id_key;
ALTER TABLE IF EXISTS ONLY public.core_servicetarget DROP CONSTRAINT IF EXISTS core_servicetarget_pkey;
ALTER TABLE IF EXISTS ONLY public.core_servicetarget DROP CONSTRAINT IF EXISTS core_servicetarget_branch_id_service_type_d_15d62a80_uniq;
ALTER TABLE IF EXISTS ONLY public.core_serviceactivity DROP CONSTRAINT IF EXISTS core_serviceactivity_pkey;
ALTER TABLE IF EXISTS ONLY public.core_retailsubsubcategory DROP CONSTRAINT IF EXISTS core_retailsubsubcategory_pkey;
ALTER TABLE IF EXISTS ONLY public.core_retailsubcategory DROP CONSTRAINT IF EXISTS core_retailsubcategory_pkey;
ALTER TABLE IF EXISTS ONLY public.core_retailsale DROP CONSTRAINT IF EXISTS core_retailsale_pkey;
ALTER TABLE IF EXISTS ONLY public.core_retailcategory DROP CONSTRAINT IF EXISTS core_retailcategory_pkey;
ALTER TABLE IF EXISTS ONLY public.core_purchaseorderitem DROP CONSTRAINT IF EXISTS core_purchaseorderitem_pkey;
ALTER TABLE IF EXISTS ONLY public.core_purchaseorder DROP CONSTRAINT IF EXISTS core_purchaseorder_pkey;
ALTER TABLE IF EXISTS ONLY public.core_product DROP CONSTRAINT IF EXISTS core_product_pkey;
ALTER TABLE IF EXISTS ONLY public.core_product DROP CONSTRAINT IF EXISTS core_product_imei_serial_key;
ALTER TABLE IF EXISTS ONLY public.core_performance DROP CONSTRAINT IF EXISTS core_performance_pkey;
ALTER TABLE IF EXISTS ONLY public.core_notification DROP CONSTRAINT IF EXISTS core_notification_pkey;
ALTER TABLE IF EXISTS ONLY public.core_multichoiceweeklyreport DROP CONSTRAINT IF EXISTS core_multichoiceweeklyreport_pkey;
ALTER TABLE IF EXISTS ONLY public.core_multichoicesale DROP CONSTRAINT IF EXISTS core_multichoicesale_pkey;
ALTER TABLE IF EXISTS ONLY public.core_multichoicebalance DROP CONSTRAINT IF EXISTS core_multichoicebalance_pkey;
ALTER TABLE IF EXISTS ONLY public.core_moniepointtransaction DROP CONSTRAINT IF EXISTS core_moniepointtransaction_transaction_id_key;
ALTER TABLE IF EXISTS ONLY public.core_moniepointtransaction DROP CONSTRAINT IF EXISTS core_moniepointtransaction_pkey;
ALTER TABLE IF EXISTS ONLY public.core_loyaltytransaction DROP CONSTRAINT IF EXISTS core_loyaltytransaction_pkey;
ALTER TABLE IF EXISTS ONLY public.core_loyaltypoint DROP CONSTRAINT IF EXISTS core_loyaltypoint_pkey;
ALTER TABLE IF EXISTS ONLY public.core_loyaltypoint DROP CONSTRAINT IF EXISTS core_loyaltypoint_customer_id_branch_id_15ef8fca_uniq;
ALTER TABLE IF EXISTS ONLY public.core_invoice DROP CONSTRAINT IF EXISTS core_invoice_pkey;
ALTER TABLE IF EXISTS ONLY public.core_invoice DROP CONSTRAINT IF EXISTS core_invoice_invoice_number_key;
ALTER TABLE IF EXISTS ONLY public.core_expense DROP CONSTRAINT IF EXISTS core_expense_pkey;
ALTER TABLE IF EXISTS ONLY public.core_directorsafestock DROP CONSTRAINT IF EXISTS core_directorsafestock_pkey;
ALTER TABLE IF EXISTS ONLY public.core_devicetagcommission DROP CONSTRAINT IF EXISTS core_devicetagcommission_pkey;
ALTER TABLE IF EXISTS ONLY public.core_devicetagcommission DROP CONSTRAINT IF EXISTS core_devicetagcommission_device_tag_id_month_year_b1a8b6de_uniq;
ALTER TABLE IF EXISTS ONLY public.core_devicetag DROP CONSTRAINT IF EXISTS core_devicetag_pkey;
ALTER TABLE IF EXISTS ONLY public.core_customer DROP CONSTRAINT IF EXISTS core_customer_pkey;
ALTER TABLE IF EXISTS ONLY public.core_customer DROP CONSTRAINT IF EXISTS core_customer_phone_number_key;
ALTER TABLE IF EXISTS ONLY public.core_commissionpayment DROP CONSTRAINT IF EXISTS core_commissionpayment_pkey;
ALTER TABLE IF EXISTS ONLY public.core_checkinoutlog DROP CONSTRAINT IF EXISTS core_checkinoutlog_pkey;
ALTER TABLE IF EXISTS ONLY public.core_branchsafestock DROP CONSTRAINT IF EXISTS core_branchsafestock_pkey;
ALTER TABLE IF EXISTS ONLY public.core_branch DROP CONSTRAINT IF EXISTS core_branch_pkey;
ALTER TABLE IF EXISTS ONLY public.core_auditlog DROP CONSTRAINT IF EXISTS core_auditlog_pkey;
ALTER TABLE IF EXISTS ONLY public.core_attendance DROP CONSTRAINT IF EXISTS core_attendance_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_name_key;
DROP TABLE IF EXISTS public.django_session;
DROP TABLE IF EXISTS public.django_migrations;
DROP TABLE IF EXISTS public.django_content_type;
DROP TABLE IF EXISTS public.django_admin_log;
DROP TABLE IF EXISTS public.core_wholesaledevicesale;
DROP TABLE IF EXISTS public.core_wholesaledevice;
DROP TABLE IF EXISTS public.core_user_user_permissions;
DROP TABLE IF EXISTS public.core_user_groups;
DROP TABLE IF EXISTS public.core_user;
DROP TABLE IF EXISTS public.core_supplier;
DROP TABLE IF EXISTS public.core_stockrequest;
DROP TABLE IF EXISTS public.core_stockmovement;
DROP TABLE IF EXISTS public.core_stockalert;
DROP TABLE IF EXISTS public.core_staffstock;
DROP TABLE IF EXISTS public.core_siminventorylog;
DROP TABLE IF EXISTS public.core_siminventory;
DROP TABLE IF EXISTS public.core_servicetarget;
DROP TABLE IF EXISTS public.core_serviceactivity;
DROP TABLE IF EXISTS public.core_retailsubsubcategory;
DROP TABLE IF EXISTS public.core_retailsubcategory;
DROP TABLE IF EXISTS public.core_retailsale;
DROP TABLE IF EXISTS public.core_retailcategory;
DROP TABLE IF EXISTS public.core_purchaseorderitem;
DROP TABLE IF EXISTS public.core_purchaseorder;
DROP TABLE IF EXISTS public.core_product;
DROP TABLE IF EXISTS public.core_performance;
DROP TABLE IF EXISTS public.core_notification;
DROP TABLE IF EXISTS public.core_multichoiceweeklyreport;
DROP TABLE IF EXISTS public.core_multichoicesale;
DROP TABLE IF EXISTS public.core_multichoicebalance;
DROP TABLE IF EXISTS public.core_moniepointtransaction;
DROP TABLE IF EXISTS public.core_loyaltytransaction;
DROP TABLE IF EXISTS public.core_loyaltypoint;
DROP TABLE IF EXISTS public.core_invoice;
DROP TABLE IF EXISTS public.core_expense;
DROP TABLE IF EXISTS public.core_directorsafestock;
DROP TABLE IF EXISTS public.core_devicetagcommission;
DROP TABLE IF EXISTS public.core_devicetag;
DROP TABLE IF EXISTS public.core_customer;
DROP TABLE IF EXISTS public.core_commissionpayment;
DROP TABLE IF EXISTS public.core_checkinoutlog;
DROP TABLE IF EXISTS public.core_branchsafestock;
DROP TABLE IF EXISTS public.core_branch;
DROP TABLE IF EXISTS public.core_auditlog;
DROP TABLE IF EXISTS public.core_attendance;
DROP TABLE IF EXISTS public.auth_permission;
DROP TABLE IF EXISTS public.auth_group_permissions;
DROP TABLE IF EXISTS public.auth_group;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_attendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_attendance (
    id bigint NOT NULL,
    session character varying(10) NOT NULL,
    check_in_time timestamp with time zone,
    check_out_time timestamp with time zone,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    distance_from_branch double precision NOT NULL,
    selfie character varying(100) NOT NULL,
    date date NOT NULL,
    is_late boolean NOT NULL,
    is_absent boolean NOT NULL,
    deduction_amount numeric(10,2) NOT NULL,
    branch_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.core_attendance OWNER TO postgres;

--
-- Name: core_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_attendance ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_attendance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_auditlog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_auditlog (
    id bigint NOT NULL,
    action character varying(10) NOT NULL,
    model_name character varying(100) NOT NULL,
    object_id integer,
    description text NOT NULL,
    ip_address inet,
    "timestamp" timestamp with time zone NOT NULL,
    user_id bigint
);


ALTER TABLE public.core_auditlog OWNER TO postgres;

--
-- Name: core_auditlog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_auditlog ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_auditlog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_branch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_branch (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    allowed_radius integer NOT NULL,
    latitude double precision,
    location_locked boolean NOT NULL,
    longitude double precision,
    city character varying(100) NOT NULL,
    state character varying(100) NOT NULL,
    street_address character varying(255) NOT NULL
);


ALTER TABLE public.core_branch OWNER TO postgres;

--
-- Name: core_branch_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_branch ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_branch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_branchsafestock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_branchsafestock (
    id bigint NOT NULL,
    quantity integer NOT NULL,
    branch_id bigint NOT NULL,
    product_id bigint NOT NULL,
    CONSTRAINT core_branchsafestock_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.core_branchsafestock OWNER TO postgres;

--
-- Name: core_branchsafestock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_branchsafestock ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_branchsafestock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_checkinoutlog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_checkinoutlog (
    id bigint NOT NULL,
    check_in_time timestamp with time zone NOT NULL,
    check_out_time timestamp with time zone,
    purpose character varying(200),
    is_checkout boolean NOT NULL,
    date date NOT NULL,
    branch_id bigint NOT NULL,
    staff_id bigint NOT NULL
);


ALTER TABLE public.core_checkinoutlog OWNER TO postgres;

--
-- Name: core_checkinoutlog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_checkinoutlog ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_checkinoutlog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_commissionpayment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_commissionpayment (
    id bigint NOT NULL,
    previous_balance numeric(12,2) NOT NULL,
    current_balance numeric(12,2) NOT NULL,
    commission_detected numeric(12,2) NOT NULL,
    date_detected timestamp with time zone NOT NULL,
    date_paid date,
    is_confirmed boolean NOT NULL,
    notes character varying(200),
    balance_record_id bigint,
    branch_id bigint NOT NULL,
    staff_id bigint NOT NULL
);


ALTER TABLE public.core_commissionpayment OWNER TO postgres;

--
-- Name: core_commissionpayment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_commissionpayment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_commissionpayment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_customer (
    id bigint NOT NULL,
    phone_number character varying(20) NOT NULL,
    name character varying(150) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    branch_id bigint NOT NULL,
    last_purchase timestamp with time zone,
    purchase_count integer NOT NULL,
    total_spent numeric(12,2) NOT NULL
);


ALTER TABLE public.core_customer OWNER TO postgres;

--
-- Name: core_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_customer ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_devicetag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_devicetag (
    id bigint NOT NULL,
    tag_name character varying(100) NOT NULL,
    branch_id bigint NOT NULL
);


ALTER TABLE public.core_devicetag OWNER TO postgres;

--
-- Name: core_devicetag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_devicetag ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_devicetag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_devicetagcommission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_devicetagcommission (
    id bigint NOT NULL,
    month_year character varying(7) NOT NULL,
    commission_amount numeric(12,2) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    branch_id bigint NOT NULL,
    created_by_id bigint,
    device_tag_id bigint NOT NULL
);


ALTER TABLE public.core_devicetagcommission OWNER TO postgres;

--
-- Name: core_devicetagcommission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_devicetagcommission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_devicetagcommission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_directorsafestock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_directorsafestock (
    id bigint NOT NULL,
    quantity integer NOT NULL,
    date_added timestamp with time zone NOT NULL,
    notes text NOT NULL,
    product_id bigint,
    CONSTRAINT core_directorsafestock_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.core_directorsafestock OWNER TO postgres;

--
-- Name: core_directorsafestock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_directorsafestock ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_directorsafestock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_expense; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_expense (
    id bigint NOT NULL,
    category character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    description text NOT NULL,
    date date NOT NULL,
    branch_id bigint NOT NULL
);


ALTER TABLE public.core_expense OWNER TO postgres;

--
-- Name: core_expense_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_expense ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_expense_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_invoice (
    id bigint NOT NULL,
    invoice_number character varying(50) NOT NULL,
    sale_type character varying(20) NOT NULL,
    sale_id integer NOT NULL,
    customer_name character varying(200) NOT NULL,
    customer_phone character varying(20) NOT NULL,
    product_description character varying(300) NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    payment_method character varying(20) NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    generated_at timestamp with time zone NOT NULL,
    emailed_to character varying(254),
    branch_id bigint NOT NULL,
    staff_id bigint NOT NULL,
    CONSTRAINT core_invoice_quantity_check CHECK ((quantity >= 0)),
    CONSTRAINT core_invoice_sale_id_check CHECK ((sale_id >= 0))
);


ALTER TABLE public.core_invoice OWNER TO postgres;

--
-- Name: core_invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_invoice ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_invoice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_loyaltypoint; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_loyaltypoint (
    id bigint NOT NULL,
    points_balance integer NOT NULL,
    total_earned integer NOT NULL,
    total_redeemed integer NOT NULL,
    tier character varying(20) NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    branch_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    CONSTRAINT core_loyaltypoint_points_balance_check CHECK ((points_balance >= 0)),
    CONSTRAINT core_loyaltypoint_total_earned_check CHECK ((total_earned >= 0)),
    CONSTRAINT core_loyaltypoint_total_redeemed_check CHECK ((total_redeemed >= 0))
);


ALTER TABLE public.core_loyaltypoint OWNER TO postgres;

--
-- Name: core_loyaltypoint_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_loyaltypoint ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_loyaltypoint_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_loyaltytransaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_loyaltytransaction (
    id bigint NOT NULL,
    transaction_type character varying(10) NOT NULL,
    points integer NOT NULL,
    amount_spent numeric(12,2) NOT NULL,
    description character varying(255) NOT NULL,
    sale_type character varying(20) NOT NULL,
    sale_id integer,
    created_at timestamp with time zone NOT NULL,
    created_by_id bigint,
    loyalty_point_id bigint NOT NULL,
    CONSTRAINT core_loyaltytransaction_points_check CHECK ((points >= 0))
);


ALTER TABLE public.core_loyaltytransaction OWNER TO postgres;

--
-- Name: core_loyaltytransaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_loyaltytransaction ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_loyaltytransaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_moniepointtransaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_moniepointtransaction (
    id bigint NOT NULL,
    transaction_id character varying(100) NOT NULL,
    customer_name character varying(150) NOT NULL,
    customer_phone character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    status character varying(10) NOT NULL,
    notes text NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    sale_type character varying(20) NOT NULL,
    sale_id integer,
    branch_id bigint NOT NULL,
    staff_id bigint NOT NULL
);


ALTER TABLE public.core_moniepointtransaction OWNER TO postgres;

--
-- Name: core_moniepointtransaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_moniepointtransaction ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_moniepointtransaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_multichoicebalance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_multichoicebalance (
    id bigint NOT NULL,
    balance_amount numeric(12,2) NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    notes character varying(200),
    weekly_report_id bigint NOT NULL,
    is_commission_payment boolean NOT NULL,
    balance_after_sale numeric(12,2),
    sale_cost_price numeric(12,2) NOT NULL
);


ALTER TABLE public.core_multichoicebalance OWNER TO postgres;

--
-- Name: core_multichoicebalance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_multichoicebalance ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_multichoicebalance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_multichoicesale; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_multichoicesale (
    id bigint NOT NULL,
    customer_name character varying(150) NOT NULL,
    package_type character varying(100) NOT NULL,
    transaction_type character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    branch_id bigint NOT NULL,
    staff_id bigint NOT NULL,
    cost_price numeric(12,2) NOT NULL,
    service_type character varying(20) NOT NULL,
    customer_phone character varying(20),
    iuc_number character varying(100)
);


ALTER TABLE public.core_multichoicesale OWNER TO postgres;

--
-- Name: core_multichoicesale_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_multichoicesale ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_multichoicesale_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_multichoiceweeklyreport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_multichoiceweeklyreport (
    id bigint NOT NULL,
    week_start_date date NOT NULL,
    opening_balance numeric(12,2) NOT NULL,
    additional_funds numeric(12,2) NOT NULL,
    closing_balance numeric(12,2),
    total_subscriptions numeric(12,2) NOT NULL,
    commission numeric(12,2) NOT NULL,
    is_closed boolean NOT NULL,
    branch_id bigint NOT NULL,
    staff_id bigint NOT NULL
);


ALTER TABLE public.core_multichoiceweeklyreport OWNER TO postgres;

--
-- Name: core_multichoiceweeklyreport_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_multichoiceweeklyreport ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_multichoiceweeklyreport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_notification (
    id bigint NOT NULL,
    notif_type character varying(20) NOT NULL,
    title character varying(200) NOT NULL,
    message text NOT NULL,
    link character varying(200) NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    recipient_id bigint NOT NULL
);


ALTER TABLE public.core_notification OWNER TO postgres;

--
-- Name: core_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_notification ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_notification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_performance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_performance (
    id bigint NOT NULL,
    service_type character varying(100) NOT NULL,
    number_achieved integer NOT NULL,
    date date NOT NULL,
    branch_id bigint NOT NULL,
    staff_id bigint NOT NULL
);


ALTER TABLE public.core_performance OWNER TO postgres;

--
-- Name: core_performance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_performance ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_performance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_product (
    id bigint NOT NULL,
    model_name character varying(100) NOT NULL,
    cost_price numeric(12,2) NOT NULL,
    selling_price numeric(12,2) NOT NULL,
    subcategory_id bigint NOT NULL,
    description text,
    subsubcategory_id bigint,
    product_name character varying(200),
    imei_serial character varying(100)
);


ALTER TABLE public.core_product OWNER TO postgres;

--
-- Name: core_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_purchaseorder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_purchaseorder (
    id bigint NOT NULL,
    status character varying(10) NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    notes text NOT NULL,
    date_ordered date NOT NULL,
    date_received date,
    branch_id bigint NOT NULL,
    ordered_by_id bigint,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.core_purchaseorder OWNER TO postgres;

--
-- Name: core_purchaseorder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_purchaseorder ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_purchaseorder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_purchaseorderitem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_purchaseorderitem (
    id bigint NOT NULL,
    quantity integer NOT NULL,
    unit_cost numeric(12,2) NOT NULL,
    order_id bigint NOT NULL,
    product_id bigint NOT NULL,
    CONSTRAINT core_purchaseorderitem_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.core_purchaseorderitem OWNER TO postgres;

--
-- Name: core_purchaseorderitem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_purchaseorderitem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_purchaseorderitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_retailcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_retailcategory (
    id bigint NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.core_retailcategory OWNER TO postgres;

--
-- Name: core_retailcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_retailcategory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_retailcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_retailsale; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_retailsale (
    id bigint NOT NULL,
    quantity integer NOT NULL,
    selling_price numeric(12,2) NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    branch_id bigint NOT NULL,
    product_id bigint NOT NULL,
    staff_id bigint NOT NULL,
    payment_method character varying(10) NOT NULL,
    customer_phone character varying(20),
    is_voided boolean NOT NULL,
    void_reason text NOT NULL,
    voided_at timestamp with time zone,
    voided_by_id bigint,
    CONSTRAINT core_retailsale_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.core_retailsale OWNER TO postgres;

--
-- Name: core_retailsale_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_retailsale ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_retailsale_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_retailsubcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_retailsubcategory (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    category_id bigint NOT NULL
);


ALTER TABLE public.core_retailsubcategory OWNER TO postgres;

--
-- Name: core_retailsubcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_retailsubcategory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_retailsubcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_retailsubsubcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_retailsubsubcategory (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    subcategory_id bigint NOT NULL
);


ALTER TABLE public.core_retailsubsubcategory OWNER TO postgres;

--
-- Name: core_retailsubsubcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_retailsubsubcategory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_retailsubsubcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_serviceactivity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_serviceactivity (
    id bigint NOT NULL,
    service_type character varying(50) NOT NULL,
    quantity integer NOT NULL,
    date date NOT NULL,
    branch_id bigint NOT NULL,
    device_tag_id bigint,
    staff_id bigint NOT NULL,
    approved boolean NOT NULL,
    requires_approval boolean NOT NULL,
    customer_phone character varying(20) NOT NULL,
    customer_name character varying(200) NOT NULL,
    price numeric(12,2) NOT NULL,
    CONSTRAINT core_serviceactivity_quantity_aed582e9_check CHECK ((quantity >= 0))
);


ALTER TABLE public.core_serviceactivity OWNER TO postgres;

--
-- Name: core_serviceactivity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_serviceactivity ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_serviceactivity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_servicetarget; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_servicetarget (
    id bigint NOT NULL,
    service_type character varying(50) NOT NULL,
    target_number integer NOT NULL,
    date date NOT NULL,
    branch_id bigint NOT NULL,
    created_by_id bigint,
    device_tag_id bigint,
    CONSTRAINT core_servicetarget_target_number_check CHECK ((target_number >= 0))
);


ALTER TABLE public.core_servicetarget OWNER TO postgres;

--
-- Name: core_servicetarget_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_servicetarget ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_servicetarget_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_siminventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_siminventory (
    id bigint NOT NULL,
    opening_balance integer NOT NULL,
    current_month integer NOT NULL,
    current_year integer NOT NULL,
    total_received integer NOT NULL,
    total_sold integer NOT NULL,
    date_updated timestamp with time zone NOT NULL,
    branch_id bigint NOT NULL
);


ALTER TABLE public.core_siminventory OWNER TO postgres;

--
-- Name: core_siminventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_siminventory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_siminventory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_siminventorylog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_siminventorylog (
    id bigint NOT NULL,
    transaction_type character varying(20) NOT NULL,
    quantity integer NOT NULL,
    description text NOT NULL,
    date_created timestamp with time zone NOT NULL,
    created_by_id bigint,
    inventory_id bigint NOT NULL
);


ALTER TABLE public.core_siminventorylog OWNER TO postgres;

--
-- Name: core_siminventorylog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_siminventorylog ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_siminventorylog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_staffstock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_staffstock (
    id bigint NOT NULL,
    quantity integer NOT NULL,
    product_id bigint NOT NULL,
    staff_id bigint NOT NULL,
    CONSTRAINT core_staffstock_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.core_staffstock OWNER TO postgres;

--
-- Name: core_staffstock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_staffstock ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_staffstock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_stockalert; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_stockalert (
    id bigint NOT NULL,
    alert_type character varying(20) NOT NULL,
    threshold integer NOT NULL,
    current_quantity integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    branch_id bigint NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.core_stockalert OWNER TO postgres;

--
-- Name: core_stockalert_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_stockalert ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_stockalert_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_stockmovement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_stockmovement (
    id bigint NOT NULL,
    quantity integer NOT NULL,
    movement_type character varying(10) NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    branch_id bigint NOT NULL,
    performed_by_id bigint NOT NULL,
    product_id bigint NOT NULL,
    CONSTRAINT core_stockmovement_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.core_stockmovement OWNER TO postgres;

--
-- Name: core_stockmovement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_stockmovement ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_stockmovement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_stockrequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_stockrequest (
    id bigint NOT NULL,
    product_name character varying(200) NOT NULL,
    quantity integer NOT NULL,
    status character varying(10) NOT NULL,
    date_requested date NOT NULL,
    branch_id bigint NOT NULL,
    staff_id bigint NOT NULL,
    CONSTRAINT core_stockrequest_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.core_stockrequest OWNER TO postgres;

--
-- Name: core_stockrequest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_stockrequest ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_stockrequest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_supplier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_supplier (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(254) NOT NULL,
    address text NOT NULL,
    notes text NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.core_supplier OWNER TO postgres;

--
-- Name: core_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_supplier ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_supplier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_user (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    role character varying(20) NOT NULL,
    failed_login_count integer NOT NULL,
    branch_id bigint,
    is_locked boolean NOT NULL
);


ALTER TABLE public.core_user OWNER TO postgres;

--
-- Name: core_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.core_user_groups OWNER TO postgres;

--
-- Name: core_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.core_user_user_permissions OWNER TO postgres;

--
-- Name: core_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_wholesaledevice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_wholesaledevice (
    id bigint NOT NULL,
    product_name character varying(200) NOT NULL,
    product_type character varying(10) NOT NULL,
    network_type character varying(5) NOT NULL,
    serial_number character varying(100) NOT NULL,
    quantity integer NOT NULL,
    cost_price numeric(12,2) NOT NULL,
    selling_price numeric(12,2) NOT NULL,
    notes text NOT NULL,
    date_added timestamp with time zone NOT NULL,
    date_updated timestamp with time zone NOT NULL,
    branch_id bigint NOT NULL,
    staff_id bigint NOT NULL,
    CONSTRAINT core_wholesaledevice_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.core_wholesaledevice OWNER TO postgres;

--
-- Name: core_wholesaledevice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_wholesaledevice ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_wholesaledevice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_wholesaledevicesale; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_wholesaledevicesale (
    id bigint NOT NULL,
    buyer_type character varying(10) NOT NULL,
    buyer_name character varying(200) NOT NULL,
    buyer_phone character varying(20) NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    payment_method character varying(20) NOT NULL,
    is_director_sale boolean NOT NULL,
    notes text NOT NULL,
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    branch_id bigint NOT NULL,
    device_id bigint NOT NULL,
    sold_by_id bigint NOT NULL,
    CONSTRAINT core_wholesaledevicesale_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.core_wholesaledevicesale OWNER TO postgres;

--
-- Name: core_wholesaledevicesale_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_wholesaledevicesale ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_wholesaledevicesale_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add content type	4	add_contenttype
14	Can change content type	4	change_contenttype
15	Can delete content type	4	delete_contenttype
16	Can view content type	4	view_contenttype
17	Can add session	5	add_session
18	Can change session	5	change_session
19	Can delete session	5	delete_session
20	Can view session	5	view_session
21	Can add branch	6	add_branch
22	Can change branch	6	change_branch
23	Can delete branch	6	delete_branch
24	Can view branch	6	view_branch
25	Can add user	7	add_user
26	Can change user	7	change_user
27	Can delete user	7	delete_user
28	Can view user	7	view_user
29	Can add device tag	8	add_devicetag
30	Can change device tag	8	change_devicetag
31	Can delete device tag	8	delete_devicetag
32	Can view device tag	8	view_devicetag
33	Can add service activity	9	add_serviceactivity
34	Can change service activity	9	change_serviceactivity
35	Can delete service activity	9	delete_serviceactivity
36	Can view service activity	9	view_serviceactivity
37	Can add service target	10	add_servicetarget
38	Can change service target	10	change_servicetarget
39	Can delete service target	10	delete_servicetarget
40	Can view service target	10	view_servicetarget
41	Can add performance	11	add_performance
42	Can change performance	11	change_performance
43	Can delete performance	11	delete_performance
44	Can view performance	11	view_performance
45	Can add product	12	add_product
46	Can change product	12	change_product
47	Can delete product	12	delete_product
48	Can view product	12	view_product
49	Can add retail category	13	add_retailcategory
50	Can change retail category	13	change_retailcategory
51	Can delete retail category	13	delete_retailcategory
52	Can view retail category	13	view_retailcategory
53	Can add branch safe stock	14	add_branchsafestock
54	Can change branch safe stock	14	change_branchsafestock
55	Can delete branch safe stock	14	delete_branchsafestock
56	Can view branch safe stock	14	view_branchsafestock
57	Can add retail sub category	15	add_retailsubcategory
58	Can change retail sub category	15	change_retailsubcategory
59	Can delete retail sub category	15	delete_retailsubcategory
60	Can view retail sub category	15	view_retailsubcategory
61	Can add staff stock	16	add_staffstock
62	Can change staff stock	16	change_staffstock
63	Can delete staff stock	16	delete_staffstock
64	Can view staff stock	16	view_staffstock
65	Can add stock movement	17	add_stockmovement
66	Can change stock movement	17	change_stockmovement
67	Can delete stock movement	17	delete_stockmovement
68	Can view stock movement	17	view_stockmovement
69	Can add retail sale	18	add_retailsale
70	Can change retail sale	18	change_retailsale
71	Can delete retail sale	18	delete_retailsale
72	Can view retail sale	18	view_retailsale
73	Can add retail sub sub category	19	add_retailsubsubcategory
74	Can change retail sub sub category	19	change_retailsubsubcategory
75	Can delete retail sub sub category	19	delete_retailsubsubcategory
76	Can view retail sub sub category	19	view_retailsubsubcategory
77	Can add multi choice sale	20	add_multichoicesale
78	Can change multi choice sale	20	change_multichoicesale
79	Can delete multi choice sale	20	delete_multichoicesale
80	Can view multi choice sale	20	view_multichoicesale
81	Can add multi choice weekly report	21	add_multichoiceweeklyreport
82	Can change multi choice weekly report	21	change_multichoiceweeklyreport
83	Can delete multi choice weekly report	21	delete_multichoiceweeklyreport
84	Can view multi choice weekly report	21	view_multichoiceweeklyreport
85	Can add expense	22	add_expense
86	Can change expense	22	change_expense
87	Can delete expense	22	delete_expense
88	Can view expense	22	view_expense
89	Can add stock request	23	add_stockrequest
90	Can change stock request	23	change_stockrequest
91	Can delete stock request	23	delete_stockrequest
92	Can view stock request	23	view_stockrequest
93	Can add attendance	24	add_attendance
94	Can change attendance	24	change_attendance
95	Can delete attendance	24	delete_attendance
96	Can view attendance	24	view_attendance
97	Can add director safe stock	25	add_directorsafestock
98	Can change director safe stock	25	change_directorsafestock
99	Can delete director safe stock	25	delete_directorsafestock
100	Can view director safe stock	25	view_directorsafestock
101	Can add multi choice balance	26	add_multichoicebalance
102	Can change multi choice balance	26	change_multichoicebalance
103	Can delete multi choice balance	26	delete_multichoicebalance
104	Can view multi choice balance	26	view_multichoicebalance
105	Can add customer	27	add_customer
106	Can change customer	27	change_customer
107	Can delete customer	27	delete_customer
108	Can view customer	27	view_customer
109	Can add check in out log	28	add_checkinoutlog
110	Can change check in out log	28	change_checkinoutlog
111	Can delete check in out log	28	delete_checkinoutlog
112	Can view check in out log	28	view_checkinoutlog
113	Can add stock alert	29	add_stockalert
114	Can change stock alert	29	change_stockalert
115	Can delete stock alert	29	delete_stockalert
116	Can view stock alert	29	view_stockalert
117	Can add device tag commission	30	add_devicetagcommission
118	Can change device tag commission	30	change_devicetagcommission
119	Can delete device tag commission	30	delete_devicetagcommission
120	Can view device tag commission	30	view_devicetagcommission
121	Can add commission payment	31	add_commissionpayment
122	Can change commission payment	31	change_commissionpayment
123	Can delete commission payment	31	delete_commissionpayment
124	Can view commission payment	31	view_commissionpayment
125	Can add sim inventory	32	add_siminventory
126	Can change sim inventory	32	change_siminventory
127	Can delete sim inventory	32	delete_siminventory
128	Can view sim inventory	32	view_siminventory
129	Can add sim inventory log	33	add_siminventorylog
130	Can change sim inventory log	33	change_siminventorylog
131	Can delete sim inventory log	33	delete_siminventorylog
132	Can view sim inventory log	33	view_siminventorylog
133	Can add supplier	34	add_supplier
134	Can change supplier	34	change_supplier
135	Can delete supplier	34	delete_supplier
136	Can view supplier	34	view_supplier
137	Can add notification	35	add_notification
138	Can change notification	35	change_notification
139	Can delete notification	35	delete_notification
140	Can view notification	35	view_notification
141	Can add purchase order	36	add_purchaseorder
142	Can change purchase order	36	change_purchaseorder
143	Can delete purchase order	36	delete_purchaseorder
144	Can view purchase order	36	view_purchaseorder
145	Can add purchase order item	37	add_purchaseorderitem
146	Can change purchase order item	37	change_purchaseorderitem
147	Can delete purchase order item	37	delete_purchaseorderitem
148	Can view purchase order item	37	view_purchaseorderitem
149	Can add audit log	38	add_auditlog
150	Can change audit log	38	change_auditlog
151	Can delete audit log	38	delete_auditlog
152	Can view audit log	38	view_auditlog
153	Can add wholesale device	39	add_wholesaledevice
154	Can change wholesale device	39	change_wholesaledevice
155	Can delete wholesale device	39	delete_wholesaledevice
156	Can view wholesale device	39	view_wholesaledevice
157	Can add wholesale device sale	40	add_wholesaledevicesale
158	Can change wholesale device sale	40	change_wholesaledevicesale
159	Can delete wholesale device sale	40	delete_wholesaledevicesale
160	Can view wholesale device sale	40	view_wholesaledevicesale
161	Can add invoice	41	add_invoice
162	Can change invoice	41	change_invoice
163	Can delete invoice	41	delete_invoice
164	Can view invoice	41	view_invoice
165	Can add loyalty point	42	add_loyaltypoint
166	Can change loyalty point	42	change_loyaltypoint
167	Can delete loyalty point	42	delete_loyaltypoint
168	Can view loyalty point	42	view_loyaltypoint
169	Can add loyalty transaction	43	add_loyaltytransaction
170	Can change loyalty transaction	43	change_loyaltytransaction
171	Can delete loyalty transaction	43	delete_loyaltytransaction
172	Can view loyalty transaction	43	view_loyaltytransaction
173	Can add moniepoint transaction	44	add_moniepointtransaction
174	Can change moniepoint transaction	44	change_moniepointtransaction
175	Can delete moniepoint transaction	44	delete_moniepointtransaction
176	Can view moniepoint transaction	44	view_moniepointtransaction
\.


--
-- Data for Name: core_attendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_attendance (id, session, check_in_time, check_out_time, latitude, longitude, distance_from_branch, selfie, date, is_late, is_absent, deduction_amount, branch_id, user_id) FROM stdin;
\.


--
-- Data for Name: core_auditlog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_auditlog (id, action, model_name, object_id, description, ip_address, "timestamp", user_id) FROM stdin;
\.


--
-- Data for Name: core_branch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_branch (id, name, allowed_radius, latitude, location_locked, longitude, city, state, street_address) FROM stdin;
\.


--
-- Data for Name: core_branchsafestock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_branchsafestock (id, quantity, branch_id, product_id) FROM stdin;
\.


--
-- Data for Name: core_checkinoutlog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_checkinoutlog (id, check_in_time, check_out_time, purpose, is_checkout, date, branch_id, staff_id) FROM stdin;
\.


--
-- Data for Name: core_commissionpayment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_commissionpayment (id, previous_balance, current_balance, commission_detected, date_detected, date_paid, is_confirmed, notes, balance_record_id, branch_id, staff_id) FROM stdin;
\.


--
-- Data for Name: core_customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_customer (id, phone_number, name, created_at, branch_id, last_purchase, purchase_count, total_spent) FROM stdin;
\.


--
-- Data for Name: core_devicetag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_devicetag (id, tag_name, branch_id) FROM stdin;
\.


--
-- Data for Name: core_devicetagcommission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_devicetagcommission (id, month_year, commission_amount, created_at, branch_id, created_by_id, device_tag_id) FROM stdin;
\.


--
-- Data for Name: core_directorsafestock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_directorsafestock (id, quantity, date_added, notes, product_id) FROM stdin;
\.


--
-- Data for Name: core_expense; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_expense (id, category, amount, description, date, branch_id) FROM stdin;
\.


--
-- Data for Name: core_invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_invoice (id, invoice_number, sale_type, sale_id, customer_name, customer_phone, product_description, quantity, unit_price, total_amount, payment_method, date, "time", generated_at, emailed_to, branch_id, staff_id) FROM stdin;
\.


--
-- Data for Name: core_loyaltypoint; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_loyaltypoint (id, points_balance, total_earned, total_redeemed, tier, updated_at, branch_id, customer_id) FROM stdin;
\.


--
-- Data for Name: core_loyaltytransaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_loyaltytransaction (id, transaction_type, points, amount_spent, description, sale_type, sale_id, created_at, created_by_id, loyalty_point_id) FROM stdin;
\.


--
-- Data for Name: core_moniepointtransaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_moniepointtransaction (id, transaction_id, customer_name, customer_phone, amount, status, notes, date, "time", created_at, sale_type, sale_id, branch_id, staff_id) FROM stdin;
\.


--
-- Data for Name: core_multichoicebalance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_multichoicebalance (id, balance_amount, date, "time", notes, weekly_report_id, is_commission_payment, balance_after_sale, sale_cost_price) FROM stdin;
\.


--
-- Data for Name: core_multichoicesale; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_multichoicesale (id, customer_name, package_type, transaction_type, amount, date, "time", branch_id, staff_id, cost_price, service_type, customer_phone, iuc_number) FROM stdin;
\.


--
-- Data for Name: core_multichoiceweeklyreport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_multichoiceweeklyreport (id, week_start_date, opening_balance, additional_funds, closing_balance, total_subscriptions, commission, is_closed, branch_id, staff_id) FROM stdin;
\.


--
-- Data for Name: core_notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_notification (id, notif_type, title, message, link, is_read, created_at, recipient_id) FROM stdin;
\.


--
-- Data for Name: core_performance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_performance (id, service_type, number_achieved, date, branch_id, staff_id) FROM stdin;
\.


--
-- Data for Name: core_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_product (id, model_name, cost_price, selling_price, subcategory_id, description, subsubcategory_id, product_name, imei_serial) FROM stdin;
\.


--
-- Data for Name: core_purchaseorder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_purchaseorder (id, status, total_amount, notes, date_ordered, date_received, branch_id, ordered_by_id, supplier_id) FROM stdin;
\.


--
-- Data for Name: core_purchaseorderitem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_purchaseorderitem (id, quantity, unit_cost, order_id, product_id) FROM stdin;
\.


--
-- Data for Name: core_retailcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_retailcategory (id, name) FROM stdin;
\.


--
-- Data for Name: core_retailsale; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_retailsale (id, quantity, selling_price, date, "time", branch_id, product_id, staff_id, payment_method, customer_phone, is_voided, void_reason, voided_at, voided_by_id) FROM stdin;
\.


--
-- Data for Name: core_retailsubcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_retailsubcategory (id, name, category_id) FROM stdin;
\.


--
-- Data for Name: core_retailsubsubcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_retailsubsubcategory (id, name, subcategory_id) FROM stdin;
\.


--
-- Data for Name: core_serviceactivity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_serviceactivity (id, service_type, quantity, date, branch_id, device_tag_id, staff_id, approved, requires_approval, customer_phone, customer_name, price) FROM stdin;
\.


--
-- Data for Name: core_servicetarget; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_servicetarget (id, service_type, target_number, date, branch_id, created_by_id, device_tag_id) FROM stdin;
\.


--
-- Data for Name: core_siminventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_siminventory (id, opening_balance, current_month, current_year, total_received, total_sold, date_updated, branch_id) FROM stdin;
\.


--
-- Data for Name: core_siminventorylog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_siminventorylog (id, transaction_type, quantity, description, date_created, created_by_id, inventory_id) FROM stdin;
\.


--
-- Data for Name: core_staffstock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_staffstock (id, quantity, product_id, staff_id) FROM stdin;
\.


--
-- Data for Name: core_stockalert; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_stockalert (id, alert_type, threshold, current_quantity, is_active, created_at, branch_id, product_id) FROM stdin;
\.


--
-- Data for Name: core_stockmovement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_stockmovement (id, quantity, movement_type, date, "time", branch_id, performed_by_id, product_id) FROM stdin;
\.


--
-- Data for Name: core_stockrequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_stockrequest (id, product_name, quantity, status, date_requested, branch_id, staff_id) FROM stdin;
\.


--
-- Data for Name: core_supplier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_supplier (id, name, phone, email, address, notes, created_at) FROM stdin;
\.


--
-- Data for Name: core_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, role, failed_login_count, branch_id, is_locked) FROM stdin;
\.


--
-- Data for Name: core_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: core_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: core_wholesaledevice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_wholesaledevice (id, product_name, product_type, network_type, serial_number, quantity, cost_price, selling_price, notes, date_added, date_updated, branch_id, staff_id) FROM stdin;
\.


--
-- Data for Name: core_wholesaledevicesale; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_wholesaledevicesale (id, buyer_type, buyer_name, buyer_phone, quantity, unit_price, total_amount, payment_method, is_director_sale, notes, date, "time", created_at, branch_id, device_id, sold_by_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	core	branch
7	core	user
8	core	devicetag
9	core	serviceactivity
10	core	servicetarget
11	core	performance
12	core	product
13	core	retailcategory
14	core	branchsafestock
15	core	retailsubcategory
16	core	staffstock
17	core	stockmovement
18	core	retailsale
19	core	retailsubsubcategory
20	core	multichoicesale
21	core	multichoiceweeklyreport
22	core	expense
23	core	stockrequest
24	core	attendance
25	core	directorsafestock
26	core	multichoicebalance
27	core	customer
28	core	checkinoutlog
29	core	stockalert
30	core	devicetagcommission
31	core	commissionpayment
32	core	siminventory
33	core	siminventorylog
34	core	supplier
35	core	notification
36	core	purchaseorder
37	core	purchaseorderitem
38	core	auditlog
39	core	wholesaledevice
40	core	wholesaledevicesale
41	core	invoice
42	core	loyaltypoint
43	core	loyaltytransaction
44	core	moniepointtransaction
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2026-06-02 11:15:00.312562+00
2	contenttypes	0002_remove_content_type_name	2026-06-02 11:15:00.325094+00
3	auth	0001_initial	2026-06-02 11:15:00.394863+00
4	auth	0002_alter_permission_name_max_length	2026-06-02 11:15:00.401892+00
5	auth	0003_alter_user_email_max_length	2026-06-02 11:15:00.408494+00
6	auth	0004_alter_user_username_opts	2026-06-02 11:15:00.418123+00
7	auth	0005_alter_user_last_login_null	2026-06-02 11:15:00.427353+00
8	auth	0006_require_contenttypes_0002	2026-06-02 11:15:00.431516+00
9	auth	0007_alter_validators_add_error_messages	2026-06-02 11:15:00.438888+00
10	auth	0008_alter_user_username_max_length	2026-06-02 11:15:00.445559+00
11	auth	0009_alter_user_last_name_max_length	2026-06-02 11:15:00.455469+00
12	auth	0010_alter_group_name_max_length	2026-06-02 11:15:00.465291+00
13	auth	0011_update_proxy_permissions	2026-06-02 11:15:00.472552+00
14	auth	0012_alter_user_first_name_max_length	2026-06-02 11:15:00.479685+00
15	core	0001_initial	2026-06-02 11:15:00.59515+00
16	admin	0001_initial	2026-06-02 11:15:00.622908+00
17	admin	0002_logentry_remove_auto_add	2026-06-02 11:15:00.631807+00
18	admin	0003_logentry_add_action_flag_choices	2026-06-02 11:15:00.641892+00
19	core	0002_performance	2026-06-02 11:15:00.668948+00
20	core	0003_user_is_locked	2026-06-02 11:15:00.681643+00
21	core	0004_alter_serviceactivity_device_tag_and_more	2026-06-02 11:15:00.733949+00
22	core	0005_alter_servicetarget_unique_together_and_more	2026-06-02 11:15:00.776959+00
23	core	0006_serviceactivity_approved_and_more	2026-06-02 11:15:00.808272+00
24	core	0007_product_retailcategory_alter_user_role_and_more	2026-06-02 11:15:00.921251+00
25	core	0008_multichoiceactivity	2026-06-02 11:15:00.955673+00
26	core	0009_retailsale	2026-06-02 11:15:00.991174+00
27	core	0010_product_description_product_imei_last_5_and_more	2026-06-02 11:15:01.068269+00
28	core	0011_product_product_name	2026-06-02 11:15:01.077394+00
29	core	0012_multichoicesale_delete_multichoiceactivity	2026-06-02 11:15:01.111372+00
30	core	0013_multichoicesale_cost_price_and_more	2026-06-02 11:15:01.16192+00
31	core	0014_remove_product_imei_last_5_product_imei_serial_and_more	2026-06-02 11:15:01.24091+00
32	core	0015_retailsale_core_retail_date_1b32aa_idx_and_more	2026-06-02 11:15:01.2921+00
33	core	0016_branch_allowed_radius_branch_latitude_and_more	2026-06-02 11:15:01.366883+00
34	core	0017_alter_branch_allowed_radius_directorsafestock	2026-06-02 11:15:01.40882+00
35	core	0018_multichoicebalance	2026-06-02 11:15:01.43882+00
36	core	0019_customer	2026-06-02 11:15:01.455863+00
37	core	0020_multichoicesale_customer_phone_and_more	2026-06-02 11:15:01.606156+00
38	core	0021_multichoicebalance_is_commission_payment_and_more	2026-06-02 11:15:01.653006+00
39	core	0022_siminventory_siminventorylog	2026-06-02 11:15:01.757221+00
40	core	0023_customer_branch_customer_last_purchase_and_more	2026-06-02 11:15:01.876412+00
41	core	0024_supplier_retailsale_is_voided_retailsale_void_reason_and_more	2026-06-02 11:15:02.088903+00
42	core	0025_serviceactivity_customer_name_serviceactivity_price_and_more	2026-06-02 11:15:02.14752+00
43	core	0026_remove_servicetarget_customer_phone_wholesaledevice_and_more	2026-06-02 11:15:02.31871+00
44	core	0027_add_invoice_model	2026-06-02 11:15:02.36588+00
45	core	0028_add_branch_address	2026-06-02 11:15:02.425195+00
46	core	0029_loyaltypoint_loyaltytransaction_and_more	2026-06-02 11:15:02.56152+00
47	sessions	0001_initial	2026-06-02 11:15:02.581954+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
98sly0gp96x0gm8w0sc6i64a5jtvoixj	eyJfY3NyZnRva2VuIjoiaW9ISExHWVNVQXNtTDJaWDVSVnliZGU3NTRDR01HZloifQ:1wUN5j:fVfQuRxD2gfG4i-OptFoa073olUNi01NWgEWAZ2x6i4	2026-06-02 13:15:27.826142+00
qu6xfa12gg0heukihyrsgizieoxwbmqu	eyJfY3NyZnRva2VuIjoiVTdHMGNkVmg5ZkY1c0VscWRicmhPRE1qbkRrSlRwSWsifQ:1wUNDL:p5OTAtQJbSCUpEBMJltzlpvd4-FbcLyFEnnGDy5txzg	2026-06-02 13:23:19.667009+00
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 176, true);


--
-- Name: core_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_attendance_id_seq', 1, false);


--
-- Name: core_auditlog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_auditlog_id_seq', 1, false);


--
-- Name: core_branch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_branch_id_seq', 1, false);


--
-- Name: core_branchsafestock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_branchsafestock_id_seq', 1, false);


--
-- Name: core_checkinoutlog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_checkinoutlog_id_seq', 1, false);


--
-- Name: core_commissionpayment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_commissionpayment_id_seq', 1, false);


--
-- Name: core_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_customer_id_seq', 1, false);


--
-- Name: core_devicetag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_devicetag_id_seq', 1, false);


--
-- Name: core_devicetagcommission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_devicetagcommission_id_seq', 1, false);


--
-- Name: core_directorsafestock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_directorsafestock_id_seq', 1, false);


--
-- Name: core_expense_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_expense_id_seq', 1, false);


--
-- Name: core_invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_invoice_id_seq', 1, false);


--
-- Name: core_loyaltypoint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_loyaltypoint_id_seq', 1, false);


--
-- Name: core_loyaltytransaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_loyaltytransaction_id_seq', 1, false);


--
-- Name: core_moniepointtransaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_moniepointtransaction_id_seq', 1, false);


--
-- Name: core_multichoicebalance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_multichoicebalance_id_seq', 1, false);


--
-- Name: core_multichoicesale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_multichoicesale_id_seq', 1, false);


--
-- Name: core_multichoiceweeklyreport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_multichoiceweeklyreport_id_seq', 1, false);


--
-- Name: core_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_notification_id_seq', 1, false);


--
-- Name: core_performance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_performance_id_seq', 1, false);


--
-- Name: core_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_product_id_seq', 1, false);


--
-- Name: core_purchaseorder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_purchaseorder_id_seq', 1, false);


--
-- Name: core_purchaseorderitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_purchaseorderitem_id_seq', 1, false);


--
-- Name: core_retailcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_retailcategory_id_seq', 1, false);


--
-- Name: core_retailsale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_retailsale_id_seq', 1, false);


--
-- Name: core_retailsubcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_retailsubcategory_id_seq', 1, false);


--
-- Name: core_retailsubsubcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_retailsubsubcategory_id_seq', 1, false);


--
-- Name: core_serviceactivity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_serviceactivity_id_seq', 1, false);


--
-- Name: core_servicetarget_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_servicetarget_id_seq', 1, false);


--
-- Name: core_siminventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_siminventory_id_seq', 1, false);


--
-- Name: core_siminventorylog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_siminventorylog_id_seq', 1, false);


--
-- Name: core_staffstock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_staffstock_id_seq', 1, false);


--
-- Name: core_stockalert_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_stockalert_id_seq', 1, false);


--
-- Name: core_stockmovement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_stockmovement_id_seq', 1, false);


--
-- Name: core_stockrequest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_stockrequest_id_seq', 1, false);


--
-- Name: core_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_supplier_id_seq', 1, false);


--
-- Name: core_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_user_groups_id_seq', 1, false);


--
-- Name: core_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_user_id_seq', 1, false);


--
-- Name: core_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_user_user_permissions_id_seq', 1, false);


--
-- Name: core_wholesaledevice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_wholesaledevice_id_seq', 1, false);


--
-- Name: core_wholesaledevicesale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_wholesaledevicesale_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 44, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 47, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: core_attendance core_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_attendance
    ADD CONSTRAINT core_attendance_pkey PRIMARY KEY (id);


--
-- Name: core_auditlog core_auditlog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_auditlog
    ADD CONSTRAINT core_auditlog_pkey PRIMARY KEY (id);


--
-- Name: core_branch core_branch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_branch
    ADD CONSTRAINT core_branch_pkey PRIMARY KEY (id);


--
-- Name: core_branchsafestock core_branchsafestock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_branchsafestock
    ADD CONSTRAINT core_branchsafestock_pkey PRIMARY KEY (id);


--
-- Name: core_checkinoutlog core_checkinoutlog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_checkinoutlog
    ADD CONSTRAINT core_checkinoutlog_pkey PRIMARY KEY (id);


--
-- Name: core_commissionpayment core_commissionpayment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_commissionpayment
    ADD CONSTRAINT core_commissionpayment_pkey PRIMARY KEY (id);


--
-- Name: core_customer core_customer_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_customer
    ADD CONSTRAINT core_customer_phone_number_key UNIQUE (phone_number);


--
-- Name: core_customer core_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_customer
    ADD CONSTRAINT core_customer_pkey PRIMARY KEY (id);


--
-- Name: core_devicetag core_devicetag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_devicetag
    ADD CONSTRAINT core_devicetag_pkey PRIMARY KEY (id);


--
-- Name: core_devicetagcommission core_devicetagcommission_device_tag_id_month_year_b1a8b6de_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_devicetagcommission
    ADD CONSTRAINT core_devicetagcommission_device_tag_id_month_year_b1a8b6de_uniq UNIQUE (device_tag_id, month_year);


--
-- Name: core_devicetagcommission core_devicetagcommission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_devicetagcommission
    ADD CONSTRAINT core_devicetagcommission_pkey PRIMARY KEY (id);


--
-- Name: core_directorsafestock core_directorsafestock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_directorsafestock
    ADD CONSTRAINT core_directorsafestock_pkey PRIMARY KEY (id);


--
-- Name: core_expense core_expense_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_expense
    ADD CONSTRAINT core_expense_pkey PRIMARY KEY (id);


--
-- Name: core_invoice core_invoice_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_invoice
    ADD CONSTRAINT core_invoice_invoice_number_key UNIQUE (invoice_number);


--
-- Name: core_invoice core_invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_invoice
    ADD CONSTRAINT core_invoice_pkey PRIMARY KEY (id);


--
-- Name: core_loyaltypoint core_loyaltypoint_customer_id_branch_id_15ef8fca_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_loyaltypoint
    ADD CONSTRAINT core_loyaltypoint_customer_id_branch_id_15ef8fca_uniq UNIQUE (customer_id, branch_id);


--
-- Name: core_loyaltypoint core_loyaltypoint_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_loyaltypoint
    ADD CONSTRAINT core_loyaltypoint_pkey PRIMARY KEY (id);


--
-- Name: core_loyaltytransaction core_loyaltytransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_loyaltytransaction
    ADD CONSTRAINT core_loyaltytransaction_pkey PRIMARY KEY (id);


--
-- Name: core_moniepointtransaction core_moniepointtransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_moniepointtransaction
    ADD CONSTRAINT core_moniepointtransaction_pkey PRIMARY KEY (id);


--
-- Name: core_moniepointtransaction core_moniepointtransaction_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_moniepointtransaction
    ADD CONSTRAINT core_moniepointtransaction_transaction_id_key UNIQUE (transaction_id);


--
-- Name: core_multichoicebalance core_multichoicebalance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_multichoicebalance
    ADD CONSTRAINT core_multichoicebalance_pkey PRIMARY KEY (id);


--
-- Name: core_multichoicesale core_multichoicesale_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_multichoicesale
    ADD CONSTRAINT core_multichoicesale_pkey PRIMARY KEY (id);


--
-- Name: core_multichoiceweeklyreport core_multichoiceweeklyreport_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_multichoiceweeklyreport
    ADD CONSTRAINT core_multichoiceweeklyreport_pkey PRIMARY KEY (id);


--
-- Name: core_notification core_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_notification
    ADD CONSTRAINT core_notification_pkey PRIMARY KEY (id);


--
-- Name: core_performance core_performance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_performance
    ADD CONSTRAINT core_performance_pkey PRIMARY KEY (id);


--
-- Name: core_product core_product_imei_serial_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_product
    ADD CONSTRAINT core_product_imei_serial_key UNIQUE (imei_serial);


--
-- Name: core_product core_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_product
    ADD CONSTRAINT core_product_pkey PRIMARY KEY (id);


--
-- Name: core_purchaseorder core_purchaseorder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_purchaseorder
    ADD CONSTRAINT core_purchaseorder_pkey PRIMARY KEY (id);


--
-- Name: core_purchaseorderitem core_purchaseorderitem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_purchaseorderitem
    ADD CONSTRAINT core_purchaseorderitem_pkey PRIMARY KEY (id);


--
-- Name: core_retailcategory core_retailcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_retailcategory
    ADD CONSTRAINT core_retailcategory_pkey PRIMARY KEY (id);


--
-- Name: core_retailsale core_retailsale_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_retailsale
    ADD CONSTRAINT core_retailsale_pkey PRIMARY KEY (id);


--
-- Name: core_retailsubcategory core_retailsubcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_retailsubcategory
    ADD CONSTRAINT core_retailsubcategory_pkey PRIMARY KEY (id);


--
-- Name: core_retailsubsubcategory core_retailsubsubcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_retailsubsubcategory
    ADD CONSTRAINT core_retailsubsubcategory_pkey PRIMARY KEY (id);


--
-- Name: core_serviceactivity core_serviceactivity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_serviceactivity
    ADD CONSTRAINT core_serviceactivity_pkey PRIMARY KEY (id);


--
-- Name: core_servicetarget core_servicetarget_branch_id_service_type_d_15d62a80_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_servicetarget
    ADD CONSTRAINT core_servicetarget_branch_id_service_type_d_15d62a80_uniq UNIQUE (branch_id, service_type, device_tag_id, date);


--
-- Name: core_servicetarget core_servicetarget_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_servicetarget
    ADD CONSTRAINT core_servicetarget_pkey PRIMARY KEY (id);


--
-- Name: core_siminventory core_siminventory_branch_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_siminventory
    ADD CONSTRAINT core_siminventory_branch_id_key UNIQUE (branch_id);


--
-- Name: core_siminventory core_siminventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_siminventory
    ADD CONSTRAINT core_siminventory_pkey PRIMARY KEY (id);


--
-- Name: core_siminventorylog core_siminventorylog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_siminventorylog
    ADD CONSTRAINT core_siminventorylog_pkey PRIMARY KEY (id);


--
-- Name: core_staffstock core_staffstock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_staffstock
    ADD CONSTRAINT core_staffstock_pkey PRIMARY KEY (id);


--
-- Name: core_stockalert core_stockalert_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_stockalert
    ADD CONSTRAINT core_stockalert_pkey PRIMARY KEY (id);


--
-- Name: core_stockmovement core_stockmovement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_stockmovement
    ADD CONSTRAINT core_stockmovement_pkey PRIMARY KEY (id);


--
-- Name: core_stockrequest core_stockrequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_stockrequest
    ADD CONSTRAINT core_stockrequest_pkey PRIMARY KEY (id);


--
-- Name: core_supplier core_supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_supplier
    ADD CONSTRAINT core_supplier_pkey PRIMARY KEY (id);


--
-- Name: core_user_groups core_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_pkey PRIMARY KEY (id);


--
-- Name: core_user_groups core_user_groups_user_id_group_id_c82fcad1_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_user_id_group_id_c82fcad1_uniq UNIQUE (user_id, group_id);


--
-- Name: core_user core_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user
    ADD CONSTRAINT core_user_pkey PRIMARY KEY (id);


--
-- Name: core_user_user_permissions core_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: core_user_user_permissions core_user_user_permissions_user_id_permission_id_73ea0daa_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permissions_user_id_permission_id_73ea0daa_uniq UNIQUE (user_id, permission_id);


--
-- Name: core_user core_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user
    ADD CONSTRAINT core_user_username_key UNIQUE (username);


--
-- Name: core_wholesaledevice core_wholesaledevice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_wholesaledevice
    ADD CONSTRAINT core_wholesaledevice_pkey PRIMARY KEY (id);


--
-- Name: core_wholesaledevicesale core_wholesaledevicesale_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_wholesaledevicesale
    ADD CONSTRAINT core_wholesaledevicesale_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: core_attendance_branch_id_1b7e28be; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_attendance_branch_id_1b7e28be ON public.core_attendance USING btree (branch_id);


--
-- Name: core_attendance_user_id_fdad1ea2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_attendance_user_id_fdad1ea2 ON public.core_attendance USING btree (user_id);


--
-- Name: core_auditl_model_n_078933_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_auditl_model_n_078933_idx ON public.core_auditlog USING btree (model_name, "timestamp");


--
-- Name: core_auditlog_user_id_3797aaab; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_auditlog_user_id_3797aaab ON public.core_auditlog USING btree (user_id);


--
-- Name: core_branchsafestock_branch_id_bdc9012d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_branchsafestock_branch_id_bdc9012d ON public.core_branchsafestock USING btree (branch_id);


--
-- Name: core_branchsafestock_product_id_d019c34d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_branchsafestock_product_id_d019c34d ON public.core_branchsafestock USING btree (product_id);


--
-- Name: core_checkinoutlog_branch_id_eb1f0b14; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_checkinoutlog_branch_id_eb1f0b14 ON public.core_checkinoutlog USING btree (branch_id);


--
-- Name: core_checkinoutlog_staff_id_74d62d1e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_checkinoutlog_staff_id_74d62d1e ON public.core_checkinoutlog USING btree (staff_id);


--
-- Name: core_commissionpayment_balance_record_id_663a2ce3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_commissionpayment_balance_record_id_663a2ce3 ON public.core_commissionpayment USING btree (balance_record_id);


--
-- Name: core_commissionpayment_branch_id_b6bc2b60; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_commissionpayment_branch_id_b6bc2b60 ON public.core_commissionpayment USING btree (branch_id);


--
-- Name: core_commissionpayment_staff_id_99258308; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_commissionpayment_staff_id_99258308 ON public.core_commissionpayment USING btree (staff_id);


--
-- Name: core_customer_branch_id_8e5d442d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_customer_branch_id_8e5d442d ON public.core_customer USING btree (branch_id);


--
-- Name: core_customer_phone_number_623ed62a_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_customer_phone_number_623ed62a_like ON public.core_customer USING btree (phone_number varchar_pattern_ops);


--
-- Name: core_devicetag_branch_id_019fb7fd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_devicetag_branch_id_019fb7fd ON public.core_devicetag USING btree (branch_id);


--
-- Name: core_devicetagcommission_branch_id_06622e36; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_devicetagcommission_branch_id_06622e36 ON public.core_devicetagcommission USING btree (branch_id);


--
-- Name: core_devicetagcommission_created_by_id_4e2b6094; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_devicetagcommission_created_by_id_4e2b6094 ON public.core_devicetagcommission USING btree (created_by_id);


--
-- Name: core_devicetagcommission_device_tag_id_6d3f1635; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_devicetagcommission_device_tag_id_6d3f1635 ON public.core_devicetagcommission USING btree (device_tag_id);


--
-- Name: core_directorsafestock_product_id_38047829; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_directorsafestock_product_id_38047829 ON public.core_directorsafestock USING btree (product_id);


--
-- Name: core_expense_branch_id_8acf5255; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_expense_branch_id_8acf5255 ON public.core_expense USING btree (branch_id);


--
-- Name: core_invoice_branch_id_f40e78fa; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_invoice_branch_id_f40e78fa ON public.core_invoice USING btree (branch_id);


--
-- Name: core_invoice_invoice_number_052322d2_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_invoice_invoice_number_052322d2_like ON public.core_invoice USING btree (invoice_number varchar_pattern_ops);


--
-- Name: core_invoice_staff_id_7fc96d3e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_invoice_staff_id_7fc96d3e ON public.core_invoice USING btree (staff_id);


--
-- Name: core_loyaltypoint_branch_id_09e6d80f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_loyaltypoint_branch_id_09e6d80f ON public.core_loyaltypoint USING btree (branch_id);


--
-- Name: core_loyaltypoint_customer_id_0041d3d7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_loyaltypoint_customer_id_0041d3d7 ON public.core_loyaltypoint USING btree (customer_id);


--
-- Name: core_loyaltytransaction_created_by_id_dea26ffe; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_loyaltytransaction_created_by_id_dea26ffe ON public.core_loyaltytransaction USING btree (created_by_id);


--
-- Name: core_loyaltytransaction_loyalty_point_id_7b980755; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_loyaltytransaction_loyalty_point_id_7b980755 ON public.core_loyaltytransaction USING btree (loyalty_point_id);


--
-- Name: core_moniep_branch__8564a7_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_moniep_branch__8564a7_idx ON public.core_moniepointtransaction USING btree (branch_id, date);


--
-- Name: core_moniep_status_064e2b_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_moniep_status_064e2b_idx ON public.core_moniepointtransaction USING btree (status);


--
-- Name: core_moniep_transac_9a6271_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_moniep_transac_9a6271_idx ON public.core_moniepointtransaction USING btree (transaction_id);


--
-- Name: core_moniepointtransaction_branch_id_26f2a786; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_moniepointtransaction_branch_id_26f2a786 ON public.core_moniepointtransaction USING btree (branch_id);


--
-- Name: core_moniepointtransaction_staff_id_cd344dc2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_moniepointtransaction_staff_id_cd344dc2 ON public.core_moniepointtransaction USING btree (staff_id);


--
-- Name: core_moniepointtransaction_transaction_id_8c7295ce_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_moniepointtransaction_transaction_id_8c7295ce_like ON public.core_moniepointtransaction USING btree (transaction_id varchar_pattern_ops);


--
-- Name: core_multichoicebalance_weekly_report_id_d305aa7c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_multichoicebalance_weekly_report_id_d305aa7c ON public.core_multichoicebalance USING btree (weekly_report_id);


--
-- Name: core_multichoicesale_branch_id_f83238d1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_multichoicesale_branch_id_f83238d1 ON public.core_multichoicesale USING btree (branch_id);


--
-- Name: core_multichoicesale_staff_id_3e71ba63; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_multichoicesale_staff_id_3e71ba63 ON public.core_multichoicesale USING btree (staff_id);


--
-- Name: core_multichoiceweeklyreport_branch_id_d1e4fbc9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_multichoiceweeklyreport_branch_id_d1e4fbc9 ON public.core_multichoiceweeklyreport USING btree (branch_id);


--
-- Name: core_multichoiceweeklyreport_staff_id_0fcbbc31; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_multichoiceweeklyreport_staff_id_0fcbbc31 ON public.core_multichoiceweeklyreport USING btree (staff_id);


--
-- Name: core_notification_recipient_id_24a3d95c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_notification_recipient_id_24a3d95c ON public.core_notification USING btree (recipient_id);


--
-- Name: core_performance_branch_id_b7a354e1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_performance_branch_id_b7a354e1 ON public.core_performance USING btree (branch_id);


--
-- Name: core_performance_staff_id_4328b87d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_performance_staff_id_4328b87d ON public.core_performance USING btree (staff_id);


--
-- Name: core_product_imei_serial_0fb3889a_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_product_imei_serial_0fb3889a_like ON public.core_product USING btree (imei_serial varchar_pattern_ops);


--
-- Name: core_product_subcategory_id_eff25cab; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_product_subcategory_id_eff25cab ON public.core_product USING btree (subcategory_id);


--
-- Name: core_product_subsubcategory_id_a59205c3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_product_subsubcategory_id_a59205c3 ON public.core_product USING btree (subsubcategory_id);


--
-- Name: core_purchaseorder_branch_id_b1f3f892; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_purchaseorder_branch_id_b1f3f892 ON public.core_purchaseorder USING btree (branch_id);


--
-- Name: core_purchaseorder_ordered_by_id_94964a24; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_purchaseorder_ordered_by_id_94964a24 ON public.core_purchaseorder USING btree (ordered_by_id);


--
-- Name: core_purchaseorder_supplier_id_0242d2c5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_purchaseorder_supplier_id_0242d2c5 ON public.core_purchaseorder USING btree (supplier_id);


--
-- Name: core_purchaseorderitem_order_id_b76edeae; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_purchaseorderitem_order_id_b76edeae ON public.core_purchaseorderitem USING btree (order_id);


--
-- Name: core_purchaseorderitem_product_id_e4cc27f0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_purchaseorderitem_product_id_e4cc27f0 ON public.core_purchaseorderitem USING btree (product_id);


--
-- Name: core_retail_branch__f5443e_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_retail_branch__f5443e_idx ON public.core_retailsale USING btree (branch_id);


--
-- Name: core_retail_date_1b32aa_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_retail_date_1b32aa_idx ON public.core_retailsale USING btree (date);


--
-- Name: core_retail_staff_i_14e004_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_retail_staff_i_14e004_idx ON public.core_retailsale USING btree (staff_id);


--
-- Name: core_retailsale_branch_id_75cf7c8a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_retailsale_branch_id_75cf7c8a ON public.core_retailsale USING btree (branch_id);


--
-- Name: core_retailsale_product_id_e7e0c289; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_retailsale_product_id_e7e0c289 ON public.core_retailsale USING btree (product_id);


--
-- Name: core_retailsale_staff_id_0585cf0f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_retailsale_staff_id_0585cf0f ON public.core_retailsale USING btree (staff_id);


--
-- Name: core_retailsale_voided_by_id_a2926419; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_retailsale_voided_by_id_a2926419 ON public.core_retailsale USING btree (voided_by_id);


--
-- Name: core_retailsubcategory_category_id_0b204b65; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_retailsubcategory_category_id_0b204b65 ON public.core_retailsubcategory USING btree (category_id);


--
-- Name: core_retailsubsubcategory_subcategory_id_b5a83487; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_retailsubsubcategory_subcategory_id_b5a83487 ON public.core_retailsubsubcategory USING btree (subcategory_id);


--
-- Name: core_serviceactivity_branch_id_f18d27ff; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_serviceactivity_branch_id_f18d27ff ON public.core_serviceactivity USING btree (branch_id);


--
-- Name: core_serviceactivity_device_tag_id_9cd095e8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_serviceactivity_device_tag_id_9cd095e8 ON public.core_serviceactivity USING btree (device_tag_id);


--
-- Name: core_serviceactivity_staff_id_c3b6d88a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_serviceactivity_staff_id_c3b6d88a ON public.core_serviceactivity USING btree (staff_id);


--
-- Name: core_servicetarget_branch_id_556d2522; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_servicetarget_branch_id_556d2522 ON public.core_servicetarget USING btree (branch_id);


--
-- Name: core_servicetarget_created_by_id_dc58be38; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_servicetarget_created_by_id_dc58be38 ON public.core_servicetarget USING btree (created_by_id);


--
-- Name: core_servicetarget_device_tag_id_25543dda; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_servicetarget_device_tag_id_25543dda ON public.core_servicetarget USING btree (device_tag_id);


--
-- Name: core_siminventorylog_created_by_id_0370e6ad; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_siminventorylog_created_by_id_0370e6ad ON public.core_siminventorylog USING btree (created_by_id);


--
-- Name: core_siminventorylog_inventory_id_08c2f765; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_siminventorylog_inventory_id_08c2f765 ON public.core_siminventorylog USING btree (inventory_id);


--
-- Name: core_staffstock_product_id_80875aa3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_staffstock_product_id_80875aa3 ON public.core_staffstock USING btree (product_id);


--
-- Name: core_staffstock_staff_id_ae8d0304; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_staffstock_staff_id_ae8d0304 ON public.core_staffstock USING btree (staff_id);


--
-- Name: core_stockalert_branch_id_5d6c66dd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_stockalert_branch_id_5d6c66dd ON public.core_stockalert USING btree (branch_id);


--
-- Name: core_stockalert_product_id_e0d51944; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_stockalert_product_id_e0d51944 ON public.core_stockalert USING btree (product_id);


--
-- Name: core_stockmovement_branch_id_c888bf1e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_stockmovement_branch_id_c888bf1e ON public.core_stockmovement USING btree (branch_id);


--
-- Name: core_stockmovement_performed_by_id_1b6db32d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_stockmovement_performed_by_id_1b6db32d ON public.core_stockmovement USING btree (performed_by_id);


--
-- Name: core_stockmovement_product_id_bd647177; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_stockmovement_product_id_bd647177 ON public.core_stockmovement USING btree (product_id);


--
-- Name: core_stockrequest_branch_id_ae6f9056; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_stockrequest_branch_id_ae6f9056 ON public.core_stockrequest USING btree (branch_id);


--
-- Name: core_stockrequest_staff_id_f5d71b91; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_stockrequest_staff_id_f5d71b91 ON public.core_stockrequest USING btree (staff_id);


--
-- Name: core_user_branch_id_90a0c1d9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_user_branch_id_90a0c1d9 ON public.core_user USING btree (branch_id);


--
-- Name: core_user_groups_group_id_fe8c697f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_user_groups_group_id_fe8c697f ON public.core_user_groups USING btree (group_id);


--
-- Name: core_user_groups_user_id_70b4d9b8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_user_groups_user_id_70b4d9b8 ON public.core_user_groups USING btree (user_id);


--
-- Name: core_user_user_permissions_permission_id_35ccf601; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_user_user_permissions_permission_id_35ccf601 ON public.core_user_user_permissions USING btree (permission_id);


--
-- Name: core_user_user_permissions_user_id_085123d3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_user_user_permissions_user_id_085123d3 ON public.core_user_user_permissions USING btree (user_id);


--
-- Name: core_user_username_36e4f7f7_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_user_username_36e4f7f7_like ON public.core_user USING btree (username varchar_pattern_ops);


--
-- Name: core_wholes_branch__b961f7_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_wholes_branch__b961f7_idx ON public.core_wholesaledevice USING btree (branch_id, staff_id);


--
-- Name: core_wholesaledevice_branch_id_41cd184f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_wholesaledevice_branch_id_41cd184f ON public.core_wholesaledevice USING btree (branch_id);


--
-- Name: core_wholesaledevice_staff_id_c0597b80; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_wholesaledevice_staff_id_c0597b80 ON public.core_wholesaledevice USING btree (staff_id);


--
-- Name: core_wholesaledevicesale_branch_id_df2085be; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_wholesaledevicesale_branch_id_df2085be ON public.core_wholesaledevicesale USING btree (branch_id);


--
-- Name: core_wholesaledevicesale_device_id_fdf59509; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_wholesaledevicesale_device_id_fdf59509 ON public.core_wholesaledevicesale USING btree (device_id);


--
-- Name: core_wholesaledevicesale_sold_by_id_eb34326c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_wholesaledevicesale_sold_by_id_eb34326c ON public.core_wholesaledevicesale USING btree (sold_by_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_attendance core_attendance_branch_id_1b7e28be_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_attendance
    ADD CONSTRAINT core_attendance_branch_id_1b7e28be_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_attendance core_attendance_user_id_fdad1ea2_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_attendance
    ADD CONSTRAINT core_attendance_user_id_fdad1ea2_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_auditlog core_auditlog_user_id_3797aaab_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_auditlog
    ADD CONSTRAINT core_auditlog_user_id_3797aaab_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_branchsafestock core_branchsafestock_branch_id_bdc9012d_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_branchsafestock
    ADD CONSTRAINT core_branchsafestock_branch_id_bdc9012d_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_branchsafestock core_branchsafestock_product_id_d019c34d_fk_core_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_branchsafestock
    ADD CONSTRAINT core_branchsafestock_product_id_d019c34d_fk_core_product_id FOREIGN KEY (product_id) REFERENCES public.core_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_checkinoutlog core_checkinoutlog_branch_id_eb1f0b14_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_checkinoutlog
    ADD CONSTRAINT core_checkinoutlog_branch_id_eb1f0b14_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_checkinoutlog core_checkinoutlog_staff_id_74d62d1e_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_checkinoutlog
    ADD CONSTRAINT core_checkinoutlog_staff_id_74d62d1e_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_commissionpayment core_commissionpayme_balance_record_id_663a2ce3_fk_core_mult; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_commissionpayment
    ADD CONSTRAINT core_commissionpayme_balance_record_id_663a2ce3_fk_core_mult FOREIGN KEY (balance_record_id) REFERENCES public.core_multichoicebalance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_commissionpayment core_commissionpayment_branch_id_b6bc2b60_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_commissionpayment
    ADD CONSTRAINT core_commissionpayment_branch_id_b6bc2b60_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_commissionpayment core_commissionpayment_staff_id_99258308_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_commissionpayment
    ADD CONSTRAINT core_commissionpayment_staff_id_99258308_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_customer core_customer_branch_id_8e5d442d_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_customer
    ADD CONSTRAINT core_customer_branch_id_8e5d442d_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_devicetag core_devicetag_branch_id_019fb7fd_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_devicetag
    ADD CONSTRAINT core_devicetag_branch_id_019fb7fd_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_devicetagcommission core_devicetagcommis_device_tag_id_6d3f1635_fk_core_devi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_devicetagcommission
    ADD CONSTRAINT core_devicetagcommis_device_tag_id_6d3f1635_fk_core_devi FOREIGN KEY (device_tag_id) REFERENCES public.core_devicetag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_devicetagcommission core_devicetagcommission_branch_id_06622e36_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_devicetagcommission
    ADD CONSTRAINT core_devicetagcommission_branch_id_06622e36_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_devicetagcommission core_devicetagcommission_created_by_id_4e2b6094_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_devicetagcommission
    ADD CONSTRAINT core_devicetagcommission_created_by_id_4e2b6094_fk_core_user_id FOREIGN KEY (created_by_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_directorsafestock core_directorsafestock_product_id_38047829_fk_core_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_directorsafestock
    ADD CONSTRAINT core_directorsafestock_product_id_38047829_fk_core_product_id FOREIGN KEY (product_id) REFERENCES public.core_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_expense core_expense_branch_id_8acf5255_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_expense
    ADD CONSTRAINT core_expense_branch_id_8acf5255_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_invoice core_invoice_branch_id_f40e78fa_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_invoice
    ADD CONSTRAINT core_invoice_branch_id_f40e78fa_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_invoice core_invoice_staff_id_7fc96d3e_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_invoice
    ADD CONSTRAINT core_invoice_staff_id_7fc96d3e_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_loyaltypoint core_loyaltypoint_branch_id_09e6d80f_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_loyaltypoint
    ADD CONSTRAINT core_loyaltypoint_branch_id_09e6d80f_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_loyaltypoint core_loyaltypoint_customer_id_0041d3d7_fk_core_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_loyaltypoint
    ADD CONSTRAINT core_loyaltypoint_customer_id_0041d3d7_fk_core_customer_id FOREIGN KEY (customer_id) REFERENCES public.core_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_loyaltytransaction core_loyaltytransact_loyalty_point_id_7b980755_fk_core_loya; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_loyaltytransaction
    ADD CONSTRAINT core_loyaltytransact_loyalty_point_id_7b980755_fk_core_loya FOREIGN KEY (loyalty_point_id) REFERENCES public.core_loyaltypoint(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_loyaltytransaction core_loyaltytransaction_created_by_id_dea26ffe_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_loyaltytransaction
    ADD CONSTRAINT core_loyaltytransaction_created_by_id_dea26ffe_fk_core_user_id FOREIGN KEY (created_by_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_moniepointtransaction core_moniepointtransaction_branch_id_26f2a786_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_moniepointtransaction
    ADD CONSTRAINT core_moniepointtransaction_branch_id_26f2a786_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_moniepointtransaction core_moniepointtransaction_staff_id_cd344dc2_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_moniepointtransaction
    ADD CONSTRAINT core_moniepointtransaction_staff_id_cd344dc2_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_multichoicebalance core_multichoicebala_weekly_report_id_d305aa7c_fk_core_mult; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_multichoicebalance
    ADD CONSTRAINT core_multichoicebala_weekly_report_id_d305aa7c_fk_core_mult FOREIGN KEY (weekly_report_id) REFERENCES public.core_multichoiceweeklyreport(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_multichoicesale core_multichoicesale_branch_id_f83238d1_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_multichoicesale
    ADD CONSTRAINT core_multichoicesale_branch_id_f83238d1_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_multichoicesale core_multichoicesale_staff_id_3e71ba63_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_multichoicesale
    ADD CONSTRAINT core_multichoicesale_staff_id_3e71ba63_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_multichoiceweeklyreport core_multichoiceweek_branch_id_d1e4fbc9_fk_core_bran; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_multichoiceweeklyreport
    ADD CONSTRAINT core_multichoiceweek_branch_id_d1e4fbc9_fk_core_bran FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_multichoiceweeklyreport core_multichoiceweeklyreport_staff_id_0fcbbc31_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_multichoiceweeklyreport
    ADD CONSTRAINT core_multichoiceweeklyreport_staff_id_0fcbbc31_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_notification core_notification_recipient_id_24a3d95c_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_notification
    ADD CONSTRAINT core_notification_recipient_id_24a3d95c_fk_core_user_id FOREIGN KEY (recipient_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_performance core_performance_branch_id_b7a354e1_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_performance
    ADD CONSTRAINT core_performance_branch_id_b7a354e1_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_performance core_performance_staff_id_4328b87d_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_performance
    ADD CONSTRAINT core_performance_staff_id_4328b87d_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_product core_product_subcategory_id_eff25cab_fk_core_reta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_product
    ADD CONSTRAINT core_product_subcategory_id_eff25cab_fk_core_reta FOREIGN KEY (subcategory_id) REFERENCES public.core_retailsubcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_product core_product_subsubcategory_id_a59205c3_fk_core_reta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_product
    ADD CONSTRAINT core_product_subsubcategory_id_a59205c3_fk_core_reta FOREIGN KEY (subsubcategory_id) REFERENCES public.core_retailsubsubcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_purchaseorder core_purchaseorder_branch_id_b1f3f892_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_purchaseorder
    ADD CONSTRAINT core_purchaseorder_branch_id_b1f3f892_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_purchaseorder core_purchaseorder_ordered_by_id_94964a24_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_purchaseorder
    ADD CONSTRAINT core_purchaseorder_ordered_by_id_94964a24_fk_core_user_id FOREIGN KEY (ordered_by_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_purchaseorder core_purchaseorder_supplier_id_0242d2c5_fk_core_supplier_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_purchaseorder
    ADD CONSTRAINT core_purchaseorder_supplier_id_0242d2c5_fk_core_supplier_id FOREIGN KEY (supplier_id) REFERENCES public.core_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_purchaseorderitem core_purchaseorderit_order_id_b76edeae_fk_core_purc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_purchaseorderitem
    ADD CONSTRAINT core_purchaseorderit_order_id_b76edeae_fk_core_purc FOREIGN KEY (order_id) REFERENCES public.core_purchaseorder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_purchaseorderitem core_purchaseorderitem_product_id_e4cc27f0_fk_core_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_purchaseorderitem
    ADD CONSTRAINT core_purchaseorderitem_product_id_e4cc27f0_fk_core_product_id FOREIGN KEY (product_id) REFERENCES public.core_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_retailsale core_retailsale_branch_id_75cf7c8a_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_retailsale
    ADD CONSTRAINT core_retailsale_branch_id_75cf7c8a_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_retailsale core_retailsale_product_id_e7e0c289_fk_core_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_retailsale
    ADD CONSTRAINT core_retailsale_product_id_e7e0c289_fk_core_product_id FOREIGN KEY (product_id) REFERENCES public.core_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_retailsale core_retailsale_staff_id_0585cf0f_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_retailsale
    ADD CONSTRAINT core_retailsale_staff_id_0585cf0f_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_retailsale core_retailsale_voided_by_id_a2926419_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_retailsale
    ADD CONSTRAINT core_retailsale_voided_by_id_a2926419_fk_core_user_id FOREIGN KEY (voided_by_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_retailsubcategory core_retailsubcatego_category_id_0b204b65_fk_core_reta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_retailsubcategory
    ADD CONSTRAINT core_retailsubcatego_category_id_0b204b65_fk_core_reta FOREIGN KEY (category_id) REFERENCES public.core_retailcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_retailsubsubcategory core_retailsubsubcat_subcategory_id_b5a83487_fk_core_reta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_retailsubsubcategory
    ADD CONSTRAINT core_retailsubsubcat_subcategory_id_b5a83487_fk_core_reta FOREIGN KEY (subcategory_id) REFERENCES public.core_retailsubcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_serviceactivity core_serviceactivity_branch_id_f18d27ff_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_serviceactivity
    ADD CONSTRAINT core_serviceactivity_branch_id_f18d27ff_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_serviceactivity core_serviceactivity_device_tag_id_9cd095e8_fk_core_devi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_serviceactivity
    ADD CONSTRAINT core_serviceactivity_device_tag_id_9cd095e8_fk_core_devi FOREIGN KEY (device_tag_id) REFERENCES public.core_devicetag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_serviceactivity core_serviceactivity_staff_id_c3b6d88a_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_serviceactivity
    ADD CONSTRAINT core_serviceactivity_staff_id_c3b6d88a_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_servicetarget core_servicetarget_branch_id_556d2522_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_servicetarget
    ADD CONSTRAINT core_servicetarget_branch_id_556d2522_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_servicetarget core_servicetarget_created_by_id_dc58be38_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_servicetarget
    ADD CONSTRAINT core_servicetarget_created_by_id_dc58be38_fk_core_user_id FOREIGN KEY (created_by_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_servicetarget core_servicetarget_device_tag_id_25543dda_fk_core_devicetag_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_servicetarget
    ADD CONSTRAINT core_servicetarget_device_tag_id_25543dda_fk_core_devicetag_id FOREIGN KEY (device_tag_id) REFERENCES public.core_devicetag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_siminventory core_siminventory_branch_id_981a3e5e_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_siminventory
    ADD CONSTRAINT core_siminventory_branch_id_981a3e5e_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_siminventorylog core_siminventorylog_created_by_id_0370e6ad_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_siminventorylog
    ADD CONSTRAINT core_siminventorylog_created_by_id_0370e6ad_fk_core_user_id FOREIGN KEY (created_by_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_siminventorylog core_siminventorylog_inventory_id_08c2f765_fk_core_simi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_siminventorylog
    ADD CONSTRAINT core_siminventorylog_inventory_id_08c2f765_fk_core_simi FOREIGN KEY (inventory_id) REFERENCES public.core_siminventory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_staffstock core_staffstock_product_id_80875aa3_fk_core_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_staffstock
    ADD CONSTRAINT core_staffstock_product_id_80875aa3_fk_core_product_id FOREIGN KEY (product_id) REFERENCES public.core_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_staffstock core_staffstock_staff_id_ae8d0304_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_staffstock
    ADD CONSTRAINT core_staffstock_staff_id_ae8d0304_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_stockalert core_stockalert_branch_id_5d6c66dd_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_stockalert
    ADD CONSTRAINT core_stockalert_branch_id_5d6c66dd_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_stockalert core_stockalert_product_id_e0d51944_fk_core_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_stockalert
    ADD CONSTRAINT core_stockalert_product_id_e0d51944_fk_core_product_id FOREIGN KEY (product_id) REFERENCES public.core_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_stockmovement core_stockmovement_branch_id_c888bf1e_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_stockmovement
    ADD CONSTRAINT core_stockmovement_branch_id_c888bf1e_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_stockmovement core_stockmovement_performed_by_id_1b6db32d_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_stockmovement
    ADD CONSTRAINT core_stockmovement_performed_by_id_1b6db32d_fk_core_user_id FOREIGN KEY (performed_by_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_stockmovement core_stockmovement_product_id_bd647177_fk_core_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_stockmovement
    ADD CONSTRAINT core_stockmovement_product_id_bd647177_fk_core_product_id FOREIGN KEY (product_id) REFERENCES public.core_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_stockrequest core_stockrequest_branch_id_ae6f9056_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_stockrequest
    ADD CONSTRAINT core_stockrequest_branch_id_ae6f9056_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_stockrequest core_stockrequest_staff_id_f5d71b91_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_stockrequest
    ADD CONSTRAINT core_stockrequest_staff_id_f5d71b91_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user core_user_branch_id_90a0c1d9_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user
    ADD CONSTRAINT core_user_branch_id_90a0c1d9_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_groups core_user_groups_group_id_fe8c697f_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_group_id_fe8c697f_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_groups core_user_groups_user_id_70b4d9b8_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_user_id_70b4d9b8_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_user_permissions core_user_user_permi_permission_id_35ccf601_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permi_permission_id_35ccf601_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_user_permissions core_user_user_permissions_user_id_085123d3_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permissions_user_id_085123d3_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_wholesaledevice core_wholesaledevice_branch_id_41cd184f_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_wholesaledevice
    ADD CONSTRAINT core_wholesaledevice_branch_id_41cd184f_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_wholesaledevicesale core_wholesaledevice_device_id_fdf59509_fk_core_whol; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_wholesaledevicesale
    ADD CONSTRAINT core_wholesaledevice_device_id_fdf59509_fk_core_whol FOREIGN KEY (device_id) REFERENCES public.core_wholesaledevice(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_wholesaledevice core_wholesaledevice_staff_id_c0597b80_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_wholesaledevice
    ADD CONSTRAINT core_wholesaledevice_staff_id_c0597b80_fk_core_user_id FOREIGN KEY (staff_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_wholesaledevicesale core_wholesaledevicesale_branch_id_df2085be_fk_core_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_wholesaledevicesale
    ADD CONSTRAINT core_wholesaledevicesale_branch_id_df2085be_fk_core_branch_id FOREIGN KEY (branch_id) REFERENCES public.core_branch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_wholesaledevicesale core_wholesaledevicesale_sold_by_id_eb34326c_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_wholesaledevicesale
    ADD CONSTRAINT core_wholesaledevicesale_sold_by_id_eb34326c_fk_core_user_id FOREIGN KEY (sold_by_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

\unrestrict QYRHj8JNfTlcnSSfowGjls5NMUjuI5ZnhBi5bjMEmgUG54MKEWhASEEsdniDMYk

